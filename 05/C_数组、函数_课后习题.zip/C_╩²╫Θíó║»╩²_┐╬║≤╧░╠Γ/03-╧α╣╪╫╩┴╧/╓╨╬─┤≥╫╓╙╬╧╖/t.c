#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <stdio.h>
#include <unistd.h>

char getch(){
    struct termios oldt, newt;
    char ch;
    tcgetattr( STDIN_FILENO, &oldt );
    newt = oldt;
    newt.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return ch;
}

int main()
{
	FILE *fp;
	char str[30][3],buf[7],input[3];
	int offset,i;
	
	fp = fopen("CP936.TXT","r");
	srand((int)time(0));
	
	for(i=0;i<30;i++){
		offset = rand()%500;
		fseek(fp,38*offset,0);//38表示一行的字节数
		fread(buf,1,6,fp);
		buf[6]='\0';
		//puts(buf);
		str[i][1] = strtol(&buf[4],NULL,16);//取后低字节
		buf[4]='\0';
		str[i][0] = strtol(buf,NULL,16);//取高字节
		//printf("%x%x\n",str[i][0],str[i][1]);
		str[i][2]='\0';//形成一个串，其实就是一个汉字
		printf("%s",str[i]);//要想看到汉字输出，将xshell的编码改成GBK
	}
	printf("\n");
	fclose(fp);
	for(i=0;i<30;i++){
		input[0] = getch();
		input[1] = getch();
		input[2] = '\0';
		if(strcmp(input,str[i]) == 0)
			printf("%s",input);
		else
			printf("--");
	}
	return 0;
}















