#include <stdio.h>
void hello(void)
{
	printf("hello world\n");
}

int main(void)
{
	hello();
	return 0;
}

