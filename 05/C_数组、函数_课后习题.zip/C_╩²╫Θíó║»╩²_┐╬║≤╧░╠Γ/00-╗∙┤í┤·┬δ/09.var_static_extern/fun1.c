int va = 7;
int getG(void)
{
	int va = 20;
	return va;
}