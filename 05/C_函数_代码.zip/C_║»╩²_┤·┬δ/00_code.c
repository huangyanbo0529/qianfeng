#include<stdio.h>

//函数声明 ：告知编译函数名、函数的参数以及返回值类型 不能实现函数体
int my_add(int a,int b);

void test01()
{
	//函数调用:函数名+(实参) 执行函数体
	int ret = my_add(100,200);
	printf("ret=%d\n",ret);
	
	//data1 data2 100 200 叫做函数的实参
	int data1=10,data2=20;
	ret = my_add(data1,data2);
	printf("ret=%d\n",ret);
}

void test02()
{
	printf("%p\n", my_add);
	
	int ret = ((int (*)(int,int))(0x4005f2))(300,400);
	printf("ret=%d\n", ret);
}
int main(int argc,char *argv[])
{
	test02();
	return 0;
}
//函数的定义：定义函数名、参数、返回值类型以及函数体
int my_add(int a,int b)
{
	return a+b;//函数体
}