#include<stdio.h>
#include<string.h>
void input_char_array(char buf[128], int size)
//void input_char_array(char *buf)
{
	//在64位平台 任意指针变量的大小为8字节
	//printf("内部sizeof(buf)=%ld\n",sizeof(buf));//8
	//尽量在函数内部不要使用sizeof测量 形参的数组名（被优化成指针变量 得到的4或8字节）
	printf("请输入一个字符串:");
	//fgets(buf,sizeof(buf),stdin);
	fgets(buf,size,stdin);
	buf[strlen(buf)-1]='\0';//去掉输入的回车符
	
	return;
}
int my_strlen(char buf[128])
{
	int len = 0;
	while(buf[len] && ++len);
	
	return len;
}
void my_strcpy(char dst[128],char src[128])
{
	//逐个元素拷贝
	int i=0;
	while((dst[i]=src[i]) && ++i);
	return;
}

int my_strcmp(char dst[128],char src[128])
{
	int flag = 0;
	int i=0;
	while( !(flag=dst[i]-src[i])  && dst[i] && ++i);
	
	return flag;
}
void test01()
{
	char buf[128]="";
	printf("sizeof(buf)=%ld\n",sizeof(buf));//128
	//定义函数 实现字符数组的键盘输入
	input_char_array(buf, sizeof(buf));
	
	printf("%s\n", buf);
	
	//定义一个函数测量字符数组buf的长度（遇到'\0'结束）
	int len = my_strlen(buf);
	printf("len=%d\n",len);
	
	char buf2[128]="";
	//定义一个函数完成将buf的字符 拷贝到buf2中（遇到'\0'）
	my_strcpy(buf2, buf);
	printf("buf2=%s\n",buf2);
	
	//定义一个函数完成buf和buf2的比较 （遇到'\0'结束 返回值>0 大于 <0 小于  ==0等于）
	int ret= my_strcmp(buf2,buf);
	if(ret == 0)
	{
		printf("%s等于%s\n", buf2,buf);
	}
	else if(ret > 0)
	{
		printf("%s大于%s\n", buf2,buf);
	}
	else if(ret < 0)
	{
		printf("%s小于%s\n", buf2,buf);
	}
}
void input_two_char_array(char buf[5][128], int row, int col)
{
	printf("请输入%d个字符数串\n", row);
	int i=0;
	for(i=0;i<row;i++)
	{
		//scanf("%s", buf[i]);
		fgets(buf[i], col, stdin);
	}
}
void print_two_char_array(char buf[5][128], int row)
{
	int i=0;
	for(i=0;i<row;i++)
	{
		printf("%s\n", buf[i]);
	}
}
void test02()
{
	char buf[5][128]={""};
	int row = sizeof(buf)/sizeof(buf[0]);
	int col = sizeof(buf[0])/sizeof(buf[0][0]);
	
	//获取键盘输入
	input_two_char_array(buf, row, col);
	
	//遍历
	print_two_char_array(buf, row);
	
}
int main(int argc,char *argv[])
{
	
	test02();
	return 0;
}
