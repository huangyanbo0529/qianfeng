#include<stdio.h>

int my_add(int a,int b)
{
	return a+b;
}
int main(int argc,char *argv[])
{
	 my_add(10,20);
	//printf("ret=%d\n", ret);
	
	return 0;
}
