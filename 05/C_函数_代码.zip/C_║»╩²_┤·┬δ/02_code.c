#include<stdio.h>

void print_int_array(int array[5], int n)
{
	//操作array等价 操作外部数组arr
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("%d ",array[i]);
	}
	printf("\n");
	array[2]=1000;
	return;
}
void test01()
{
	int arr[5]={10,20,30,40,50};
	int n = sizeof(arr)/sizeof(arr[0]);
	
	//实现函数完成int数组的遍历
	print_int_array(arr, n);
	
	printf("函数外部arr[2]=%d\n",arr[2]);
}

void input_int_array(int arr[10], int n)
{
	printf("请输入%d个int数值:", n);
	int i=0;
	for(i=0;i<n;i++)
	{
		scanf("%d", &arr[i]);
	}
	
	return;
}
int get_max_from_array(int arr[10], int n)
{
	//假设第0个元素为最大值
	int max = arr[0];
	int i=0;
	for(i=1;i<n;i++)
	{
		if(max<arr[i])
			max = arr[i];
	}
	
	return max;
}
void test02()
{
	int arr[5]={0};
	int n = sizeof(arr)/sizeof(arr[0]);
	
	//实现函数完成 数组的输入
	input_int_array(arr, n);
	
	//实现函数完成 数组的最大值
	int max = get_max_from_array(arr, n);
	printf("max=%d\n",max);
}


void input_int_two_array(int arr[3][4], int row, int col)
{
	printf("请输入%d个int数值:",row*col);
	int i=0;
	for(i=0;i<row;i++)
	{
		int j = 0;
		for(j=0;j<col;j++)
		{
			scanf("%d", &arr[i][j]);
		}
	}
	return;
}
void print_int_two_array(int arr[3][4], int row, int col)
{
	int i=0;
	for(i=0;i<row;i++)
	{
		int j = 0;
		for(j=0;j<col;j++)
		{
			printf("%d ", arr[i][j]);
		}
		printf("\n");
	}
}
void test03()
{
	int arr[3][4]={0};
	int row = sizeof(arr)/sizeof(arr[0]);
	int col = sizeof(arr[0])/sizeof(arr[0][0]);
	
	//实现函数完成 数组的输入
	input_int_two_array(arr, row, col);
	
	//实现函数完成遍历
	print_int_two_array(arr, row, col);
}
int main(int argc,char *argv[])
{
	
	test03();
	return 0;
}
