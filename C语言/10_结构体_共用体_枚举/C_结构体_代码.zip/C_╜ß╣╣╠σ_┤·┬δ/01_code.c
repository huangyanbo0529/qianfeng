#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct stu
{
    int num;
    char *name; // 指针成员 保存的是外部字符串的首元素地址
    float score;
} STU; // STU就是struct stu类型
void test01()
{
    // 结构体在堆区
    STU *p = (STU *)malloc(sizeof(STU));
    (*p).num = 100;
    (*p).name = (char *)malloc(32); // 指向在堆区
    strcpy((*p).name, "hello world");
    (*p).score = 88.8f;

    printf("%d %s %f\n", (*p).num, (*p).name, (*p).score);
    free((*p).name);
    free(p);
}

void test02()
{
    STU lucy;
    lucy.num = 100;
    lucy.name = (char *)malloc(32);
    strcpy(lucy.name, "lucy");
    lucy.score = 88.8f;

    STU bob;
    // 浅拷贝
    bob = lucy;

    printf("%d %s %f\n", bob.num, bob.name, bob.score);

    if (lucy.name != NULL)
    {
        free(lucy.name);
        lucy.name = NULL;
    }

    if (bob.name != NULL)
    {
        free(bob.name);
        bob.name = NULL;
    }
}

void test03()
{
    STU lucy;
    STU *p = &lucy;

    p->name = (char *)malloc(32);
    printf("请输入num name score:");
    scanf("%d %s %f", &p->num, p->name, &p->score);

    printf("%d %s %f\n", p->num, p->name, p->score);
    free(p->name);
}

void test04()
{
    // 结构体数组在 栈区
    STU edu[5];
    int n = sizeof(edu) / sizeof(edu[0]);

    // 为数组的每个元素中的name申请堆区
    int i = 0;
    for (i = 0; i < n; i++)
    {
        edu[i].name = (char *)malloc(32);
        if (NULL == edu[i].name)
            return;
    }

    // 获取键盘输入
    for (i = 0; i < n; i++)
    {
        scanf("%d %s %f", &edu[i].num, edu[i].name, &edu[i].score);
    }

    // 输出
    for (i = 0; i < n; i++)
    {
        printf("%d %s %f\n", edu[i].num, edu[i].name, edu[i].score);
    }

    // 释放空间
    for (i = 0; i < n; i++)
    {
        if (edu[i].name != NULL)
        {
            free(edu[i].name);
            edu[i].name = NULL;
        }
    }
}

void test05()
{
    // 结构体数组在 栈区
    STU *edu = (STU *)calloc(5, sizeof(STU));
    if (NULL == edu)
    {
        return;
    }
    int n = 3;

    // 为数组的每个元素中的name申请堆区
    int i = 0;
    for (i = 0; i < n; i++)
    {
        (edu + i)->name = (char *)malloc(32);
        if (NULL == (edu + i)->name)
            return;
    }

    // 获取键盘输入
    for (i = 0; i < n; i++)
    {
        scanf("%d %s %f", &(edu + i)->num, (edu + i)->name, &(edu + i)->score);
    }

    // 输出
    for (i = 0; i < n; i++)
    {
        printf("%d %s %f\n", (edu + i)->num, (edu + i)->name, (edu + i)->score);
    }

    // 释放指针成员 指向的空间
    for (i = 0; i < n; i++)
    {
        if ((edu + i)->name != NULL)
        {
            free((edu + i)->name);
            (edu + i)->name = NULL;
        }
    }
    // 释放结构体数组的空间（堆区）
    if (edu != NULL)
    {
        free(edu);
        edu = NULL;
    }
}

void test06()
{
    // 为指针数组申请堆区空间
    int n = 5;
    STU **arr = (STU **)calloc(n, sizeof(STU *));
    if (NULL == arr)
    {
        printf("calloc\n");
        return;
    }

    // 为指针数组的每个元素申请空间
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // arr[i]就是指针数组的每个元素为STU *
        arr[i] = (STU *)malloc(sizeof(STU));
        if (arr[i] == NULL)
            return;

        // 为每个元素中的指针成员name申请空间
        arr[i]->name = (char *)malloc(32);
        if (arr[i]->name == NULL)
            return;
    }

    // 获取键盘输入
    //  获取键盘输入
    for (i = 0; i < n; i++)
    {
        scanf("%d %s %f", &arr[i]->num, arr[i]->name, &arr[i]->score);
    }

    // 输出
    for (i = 0; i < n; i++)
    {
        printf("%d %s %f\n", arr[i]->num, arr[i]->name, arr[i]->score);
    }

    for (i = 0; i < n; i++)
    {
        // 释放指针数组中每个元素指向的结构体中指针成员指向的堆区空间
        if (arr[i]->name != NULL)
        {
            free(arr[i]->name);
            arr[i]->name = NULL;
        }

        // 释放指针数组每个元素指向的堆区空间
        if (arr[i] != NULL)
        {
            free(arr[i]);
            arr[i] = NULL;
        }
    }

    // 释放指针数组的空间
    if (arr != NULL)
    {
        free(arr);
        arr = NULL;
    }
}

int my_add(int x, int y)
{
    return x + y;
}
int my_sub(int x, int y)
{
    return x - y;
}

struct calc
{
    int x;
    int y;

    // 函数指针成员
    int (*func)(int, int);
};

void test07()
{
    struct calc ob1 = {100, 200, my_add};
    printf("%d\n", ob1.func(ob1.x, ob1.y));

    struct calc ob2 = {100, 200, my_sub};
    printf("%d\n", ob2.func(ob2.x, ob2.y));
}
int main(int argc, char const *argv[])
{
    test07();
    return 0;
}
