#include <stdio.h>
#include <string.h>
// struct stu 才是结构体的完整类型
struct stu
{
    int num; // 成员 定义类型的时候 不要给成员赋值
    char name[32];
    float score;
};
void test01()
{
    // 结构体变量初始化时 必须遵循成员自身类型以及成员顺序
    struct stu lucy = {100, "lucy", 88.8f};
    struct stu bob;
    memset(&bob, 0, sizeof(bob)); // 将结构体变量清0

    // 将lucy内容 赋值 给bob（方法1：逐个成员操作）
    // bob.num = lucy.num;
    // strcpy(bob.name, lucy.name);
    // bob.score = lucy.score;

    // 将lucy内容 赋值 给bob（方法2：相同类型的结构体变量可以=赋值,浅拷贝）
    // bob = lucy;

    // 将lucy内容 赋值 给bob（方法3：memcpy）
    memcpy(&bob, &lucy, sizeof(struct stu));

    printf("%d %s %f\n", lucy.num, lucy.name, lucy.score);
    printf("%d %s %f\n", bob.num, bob.name, bob.score);
}

void test02()
{
    struct stu lucy;
    memset(&lucy, 0, sizeof(struct stu));

    printf("请输入学号 姓名 分数:");
    scanf("%d %s %f", &lucy.num, lucy.name, &lucy.score);

    printf("%d %s %f\n", lucy.num, lucy.name, lucy.score);
}

struct A
{
    int a;
};
struct B
{
    int a;
    struct A ob; // 结构体嵌套了结构体
};
void test03()
{
    struct B data = {100, {200}};
    printf("%d %d\n", data.a, data.ob.a);
}
void input_struct_stu_array(struct stu *arr, int n)
{
    printf("请输入%d个学生信息\n", n);
    int i = 0;
    for (i = 0; i < n; i++)
    {
        scanf("%d %s %f", &arr[i].num, arr[i].name, &arr[i].score);
    }
    return;
}
void print_struct_stu_array(struct stu *arr, int n)
{
    int i = 0;
    for (i = 0; i < n; i++)
    {
        printf("%d %s %f\n", arr[i].num, arr[i].name, arr[i].score);
    }
    return;
}
void test05()
{
    struct stu edu[5];
    int n = sizeof(edu) / sizeof(edu[0]);

    // 给这个5个学员获取数据
    input_struct_stu_array(edu, n);

    // 遍历结构体数组
    print_struct_stu_array(edu, n);
}
int main(int argc, char const *argv[])
{
    test05();
    return 0;
}
