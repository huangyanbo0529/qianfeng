#include <stdio.h>
struct A
{
    // 0~7
    unsigned int a : 3; // 位域  a类型为unsigned int 只是占空间3位二进制位
};
void test01()
{
    struct A ob1;
    ob1.a = 10;            // 1010
    printf("%u\n", ob1.a); // 2
}

struct B
{
    int a : 3;
};
void test02()
{
    struct B ob1;
    ob1.a = 14;            // 1110
    printf("%d\n", ob1.a); // -2
}

struct C
{
    // 相邻且相同类型的位域 为相邻位域
    // 相邻位域可以压缩 但是压缩的位数 不能超过 成员自身类型为位数
    unsigned char a : 4;
    unsigned char : 2; // 另起一个存储单元
    unsigned char b : 2;
};

void test03()
{
    printf("%ld\n", sizeof(struct C));
}

union D
{
    char a;
    short b;
    int c;
};

void test04()
{
    printf("%ld\n", sizeof(union D));
    union D ob1;
    ob1.a = 10;
    ob1.b = 20;
    ob1.c = 30;
    printf("%d\n", ob1.a + ob1.b + ob1.c); // 90
}
// 枚举类型 枚举列表中的值 默认从0开始递增
enum POOKER
{
    HONGTAO,
    MEIHUA = 3,
    FANGKUAI,
    HEITAO
};
void test05()
{
    enum POOKER pooker_color = HONGTAO;                         // 赋值其他值比如30  没有任何意义
    printf("%d %d %d %d\n", HONGTAO, MEIHUA, FANGKUAI, HEITAO); // 0 3 4 5
}

enum BOOL{false,true};
void test06()
{
    enum BOOL flag;
    flag = true;
    if(flag)
    {
        printf("为真\n");
    }
    else{
        printf("为假\n");
    }
}
int main(int argc, char const *argv[])
{
    test06();
    return 0;
}
