#include <stdio.h>

struct A
{
    char a; // 1B
    short c;
    int b; // 4B
};
void test01()
{
    struct A ob1;
    printf("%ld\n", sizeof(struct A));
}

struct B
{
    char a;
    short b;
};
struct C
{
    short c;
    struct B d;
    short e;
    int f;
};
void test02()
{
    struct C ob1;
    printf("%ld\n", sizeof(struct C));
}

//#pragma pack(8)
struct D
{
    char a;
    double b;//在ubunt64位的gcc环境下 double按8字节对齐
};
void test03()
{
    printf("%ld\n", sizeof(struct D));
}
int main(int argc, char const *argv[])
{
    test03();
    return 0;
}
