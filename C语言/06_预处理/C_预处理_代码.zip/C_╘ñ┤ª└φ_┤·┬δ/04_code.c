#include <stdio.h>
#include <04_fun.h>
int main(int argc, char *argv[])
{
	printf("%d\n", my_add(100,20));
	printf("%d\n", my_sub(100,20));
	printf("%d\n", my_mul(100,20));
	printf("%d\n", my_div(100,20));
	
	return 0;
}