#include <stdio.h>
#include "a.h"
#include "b.h"

int main(int argc,char *argv[])
{
	printf("data=%d\n",data);
}
