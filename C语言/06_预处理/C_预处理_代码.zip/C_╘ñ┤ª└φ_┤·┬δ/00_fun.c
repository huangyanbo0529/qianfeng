#include <stdio.h>
static void func()
{
	printf("00_fun.c中的函数\n");
}
