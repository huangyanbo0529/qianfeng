#include <stdio.h>
#include <string.h>
int main(int argc,char *argv[])
{
	char buf[128]="";
	printf("请输入一个字符串:");
	fgets(buf,sizeof(buf), stdin);
	buf[strlen(buf)-1]='\0';
	
	//将大小 转换成小写
	int i=0;
	while(buf[i] != '\0')
	{
		#if BIG_TO_SMALL
		if(buf[i]>='A' && buf[i]<='Z')
		{
			buf[i] += 32;
		}
		#else
		if(buf[i]>='a' && buf[i]<='z')
		{
			buf[i]-=32;
		}
		#endif
		
		i++;
	}
	
	printf("%s\n", buf);
}
