#include <stdio.h>

struct stu
{
	int a;
	#define N 100
};


int main(int argc,char *argv[])
{
	struct stu lucy;
	lucy.a;
	lucy.N;//没有N成员 无效
}
