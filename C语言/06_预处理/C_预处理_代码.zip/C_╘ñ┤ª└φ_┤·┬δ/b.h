#pragma once

int data = 100;

