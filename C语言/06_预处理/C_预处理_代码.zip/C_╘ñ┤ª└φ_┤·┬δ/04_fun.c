int my_add(int a, int b)
{
	return a+b;
}
int my_sub(int a, int b)
{
	return a-b;
}
int my_mul(int a, int b)
{
	return a*b;
}
int my_div(int a, int b)
{
	return a/b;
}