#include <stdio.h>

extern void func();
void test01()
{
	func();
}
int main(int argc,char *argv[])
{
	test01();
}

