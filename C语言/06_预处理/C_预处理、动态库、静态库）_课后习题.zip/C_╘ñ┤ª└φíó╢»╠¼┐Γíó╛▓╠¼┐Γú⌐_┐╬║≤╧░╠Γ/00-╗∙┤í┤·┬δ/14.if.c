#include <stdio.h>
#define BIG(x) (x)*2
int main( int argc,char *argv[])
{
	char str[20] = "C Language",C;
	int i = 0;
	while( ( C= str[i++] ) !='\0')
	{ 
		#if  BIG(argv[1])
			if( C>='a' && C<='z')
			C=C-32;
		#else
			if( C>='A'&& C<='Z')
			C=C+32;
		#endif
		printf("%c",C);
	}
	return 0;
}