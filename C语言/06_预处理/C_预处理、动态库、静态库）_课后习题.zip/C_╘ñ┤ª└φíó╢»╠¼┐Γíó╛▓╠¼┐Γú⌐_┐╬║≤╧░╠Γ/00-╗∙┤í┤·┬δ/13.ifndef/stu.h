//#ifndef __STU_H__
//#define __STU_H__
struct stu
{
	int num;
	int age;
};
//#endif