#include "stu.h"
extern int max(int x,int y);
extern int min(int x,int y);
