#include <stdio.h>
#include "fun.h"
int main(int argc, char const *argv[])
{
    printf("%d\n", my_add(100, 200));
    printf("%d\n", my_sub(100, 200));
    printf("%d\n", my_mul(100, 200));
    printf("%d\n", my_div(100, 200));

    return 0;
}
