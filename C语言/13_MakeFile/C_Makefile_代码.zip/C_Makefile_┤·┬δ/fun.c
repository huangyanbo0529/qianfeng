int my_add(int x,int y)
{
    return x+y;
}
int my_sub(int x,int y)
{
    return x-y;
}
int my_mul(int x,int y)
{
    return x*y;
}
int my_div(int x,int y)
{
    return x/y;
}
