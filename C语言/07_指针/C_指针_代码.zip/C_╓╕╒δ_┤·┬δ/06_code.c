#include <stdio.h>
#include <string.h>
int my_add(int x, int y)
{
    return x + y;
}
int my_sub(int x, int y)
{
    return x - y;
}
int my_mul(int x, int y)
{
    return x * y;
}
int my_div(int x, int y)
{
    return x / y;
}
int my_max(int x, int y)
{
    return (x > y ? x : y);
}

// 字符指针数组
char *str_buf[] = {"add", "sub", "mul", "div", "max"};
// 函数指针数组
int (*fun_buf[])(int, int) = {my_add, my_sub, my_mul, my_div, my_max};
int n = sizeof(str_buf) / sizeof(str_buf[0]);

int main(int argc, char const *argv[])
{
    while (1)
    {
        char cmd[32] = "";
        int data1 = 0, data2 = 0;
        printf("请输入add 100 200:");
        scanf("%s %d %d", cmd, &data1, &data2);
        int i = 0;
        for (i = 0; i < n; i++)
        {
            if (strcmp(str_buf[i], cmd) == 0)
            {
                printf("%d\n", fun_buf[i](data1, data2));
            }
        }
    }

    return 0;
}
