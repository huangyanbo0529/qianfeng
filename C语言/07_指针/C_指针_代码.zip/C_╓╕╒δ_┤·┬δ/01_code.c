#include <stdio.h>
#if 0
void test01()
{
    // p1是局部指针变量 不初始化 指向不确定的空间  一旦操作 容易访问非法内存
    int *p1;

    int data = 10;
    // p2指向了data &data赋值给p2，而不是*p2  这是定义语句*描述p2为指针变量
    int *p2 = &data;

    int num = 10, *p3 = &num;

    // NULL本质为（void *）0, 如果指针变量初始化为NULL 不要立即操作
    int *p4 = NULL;

    int data1 = 10;
    p4 = &data1;
    printf("*p4=%d\n", *p4);
    int data2 = 20;
    p4 = &data2;
    printf("*p4=%d\n", *p4);
}

void test02()
{
    unsigned int data = 0x01020304;
    unsigned int *p1 = &data;
    printf("%#x\n", *p1); // 0x1020304

    short *p2 = &data;
    printf("%#x\n", *p2); // 0x304

    char *p3 = &data;
    printf("%#x\n", *p3); // 0x4
}

void test03()
{
    int data = 10;
    int *p1 = &data;
    printf("%lu\n", p1);
    printf("%lu\n", p1 + 1);

    short *p2 = &data;
    printf("%lu\n", p2);
    printf("%lu\n", p2 + 1);
}


void test04()
{
    int data = 0x01020304;
    short *p1 = &data;
    printf("%#x\n", *(p1 + 1)); // 0x0102
    char *p2 = &data;
    printf("%#x\n", *(p2 + 2)); // 0x2

    char *p3 = &data;
    printf("%#x\n", *(short *)(p3 + 1)); // 0x203
}

void test05()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int n = sizeof(arr) / sizeof(arr[0]);

    // 数组名作为类型 代表的是数组的总大小==sizeof(arr)
    // 数组名作为地址 代表的是数组的首元素地址 arr==&arr[0]
    printf("&arr[0] = %p\n", &arr[0]); // 0x7ffdf2afb0e0
    printf("arr = %p\n", arr);         // 0x7ffdf2afb0e0
    printf("arr+1 = %p\n", arr + 1);   // 0x7ffdf2afb0e4

    // int *p = &arr[0];
    int *p = arr;
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // printf("%d ", *(p + i));
        printf("%d ", *(arr + i));
        // printf("%d ", arr[i]);
    }
    printf("\n");
}

void test06()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int *p = arr;

    // p本质是变量 可以被赋值
    p++;
    printf("*p=%d\n", *p); // 20

    // arr++;//arr=arr+1 arr是数组名是符号常量 不能被赋值
}

void test07()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int n = sizeof(arr) / sizeof(arr[0]);
    int *p = arr;
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // scanf("%d", &arr[i]);
        // scanf("%d", p + i);
        scanf("%d", arr + i);
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void test08()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int *p1 = &arr[0];
    int *p2 = &arr[3];

    printf("%d\n", p2 - p1);//3
}
#endif
void test09()
{
    int arr[5] = {10, 20, 30, 40, 50};
    printf("arr[1]=%d\n", arr[1]);
    printf("*(arr+1)=%d\n", *(arr + 1));
    printf("------------------------------------\n");
    printf("*(arr+1)=%d\n", *(1 + arr));
    printf("*(arr+1)=%d\n", 1 [arr]); // 千万别这样写
    // arr[i]的展开 *(arr+i)   []是*（）的缩写
    // arr==&arr[0] == &*(arr+0) == arr+0==arr
}

void test10()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int *p = arr;
    printf("%d\n", *p++);//10
    printf("%d\n", (*p)++);//20
    printf("%d\n", *(p++));//21
}
int main(int argc, char *argv[])
{
    test10();
    return 0;
}
