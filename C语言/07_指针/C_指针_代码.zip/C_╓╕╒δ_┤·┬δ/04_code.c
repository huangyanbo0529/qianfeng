#include <stdio.h>

int my_add(int x, int y)
{
    return x + y;
}
int my_sub(int x, int y)
{
    return x + y;
}
void test01()
{
    // 定义一个指针变量p保存my_add的入口地址
    int (*p)(int x, int y) = NULL;
    p = my_sub;
    // 如何通过p调用这个my_add函数呢？
    printf("%d\n", p(100, 200));
    // 不要对函数指针变量取* 会被编译器优化掉
    printf("%d\n", (***********p)(100, 200));
    printf("%d\n", my_add(100, 200));
}
int main(int argc, char const *argv[])
{
    test01();
    return 0;
}
