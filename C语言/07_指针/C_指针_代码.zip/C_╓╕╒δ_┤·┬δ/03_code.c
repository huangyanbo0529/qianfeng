#include <stdio.h>
void set_data01(int a) // int a=data;
{
    a = 1000;
}

void set_data02(int *p) // int *p=&data;
{
    //*p等价data
    *p = 1000; // data=1000
}
void test01()
{
    int data = 0;
    set_data02(&data);
    printf("data=%d\n", data); // 1000
}
// void print_int_array(int arr[5], int n)
void print_int_array(int *arr, int n)
{
    printf("内部sizeof(arr)=%ld\n", sizeof(arr)); // 8B
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // printf("%d ", *(arr+i));
        printf("%d ", arr[i]);
    }
    printf("\n");
}
void test02()
{
    int arr[5] = {1, 2, 3, 4, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    printf("外部sizeof(arr)=%ld\n", sizeof(arr)); // 20B
    print_int_array(arr, n);
}
// void print_int_two_array(int arr[3][4], int row, int col)
void print_int_two_array(int (*arr)[4], int row, int col)
{
    printf("内部sizeof(arr)=%ld\n", sizeof(arr)); // 8B
    // 函数内部使用arr等价使用外部的arr
    int i = 0;
    for (i = 0; i < row; i++)
    {
        int j = 0;
        for (j = 0; j < col; j++)
        {
            printf("%d ", arr[i][j]); //*(*(arr+i)+j)
        }
        printf("\n");
    }
}
void test03()
{
    int arr[3][4] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    int row = sizeof(arr) / sizeof(arr[0]);
    int col = sizeof(arr[0]) / sizeof(arr[0][0]);
    printf("外部sizeof(arr)=%ld\n", sizeof(arr)); // 48B
    print_int_two_array(arr, row, col);
}
void get_max_min_data(int *arr, int n, int *p_max, int *p_min)
{
    //*p_max等价max  *p_min=min
    int max = arr[0], min = arr[0];
    int i = 0;
    for (i = 1; i < n; i++)
    {
        max = (max < arr[i] ? arr[i] : max);
        min = (min > arr[i] ? arr[i] : min);
    }

    // 更新外部变量的值
    *p_max = max;
    *p_min = min;
    return;
}
void input_int_array(int *arr, int n)
{
    printf("请输入%d个int数据:", n);
    int i = 0;
    for (i = 0; i < n; i++)
    {
        scanf("%d", arr + i);
    }
    return;
}
void test04()
{
    int arr[10] = {0};
    int n = sizeof(arr) / sizeof(arr[0]);
    int max = 0, min = 0;

    // 键盘输入10个int数组 求出最大值和最小值 必须通过函数的形参更新
    input_int_array(arr, n);

    get_max_min_data(arr, n, &max, &min);

    printf("max=%d, min=%d\n", max, min);
}
void set_addr(int **p1)
{
    int data = 100;
    *p1 = &data;
}
void test05()
{
    int *p;
    set_addr(&p);
    printf("%d\n", *p); // 100 + 访问非法内存
}
int *get_addr(void)
{
    // data为静态局部变量 进程结束才释放 函数结束不释放
    static int data = 10;
    return &data;
}
void test06()
{
    int *p = get_addr();
    printf("*p=%d\n", *p); // 访问非法内存
}


int main(int argc, char const *argv[])
{
    test06();
    return 0;
}
