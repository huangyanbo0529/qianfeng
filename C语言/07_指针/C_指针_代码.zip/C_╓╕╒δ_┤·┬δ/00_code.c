#include <stdio.h>
void test01()
{
	printf("%ld\n",sizeof(char *));
	printf("%ld\n",sizeof(short *));
	printf("%ld\n",sizeof(int *));
	printf("%ld\n",sizeof(long *));
	printf("%ld\n",sizeof(float *));
	printf("%ld\n",sizeof(double *));
	printf("%ld\n",sizeof(int ********************));
}

void test02()
{
	int data = 10;//4字节合法地址
	//&取变量的地址
	printf("%p\n", &data);
	
	//定义指针变量p 保存&data
	//不要操作 没有合法指向的指针变量
	int *p;//定义的时候*仅仅修饰p为指针变量（重要！！！！）
	
	//建立p和data地址的关系
	p = &data;
	//p保存了data的地址
	//p指向了data
	//p保存。。。的地址 就是 p指向了。。。
	
	
	//p保存的是data的地址 所以 p的值 就是data的地址编号
	printf("%p\n", p);
	printf("%p\n", &data);
	
	printf("%d %d\n",data, *p);
}
int main(int argc, char *argv[])
{
	test02();
	return 0;
}