#include <stdio.h>

void test01()
{
    int data1 = 10;
    int data2 = 20;
    int data3 = 30;

    // 定义指针数组 存放变量的地址编号
    int *arr[3] = {&data1, &data2, &data3};
    int n = sizeof(arr) / sizeof(arr[0]);
    int i = 0;
    for (i = 0; i < n; i++)
    {
        printf("%d ", *arr[i]);
    }
    printf("\n");
}

void test02()
{
    char buf[] = "hello world";
    buf[1] = 'E';
    printf("%s\n", buf);

    char *buf1 = "hello world";
    // buf1[1] = 'E';//给只读的空间赋值 段错误
}

void test03()
{
    char *arr[5] = {"hehehehe", "hahahaha", "xixixixi", "lalalalala", "henhenhenhen"};
    int n = sizeof(arr) / sizeof(arr[0]);

    int i = 0;
    for (i = 0; i < n; i++)
    {
        printf("%s\n", arr[i]);
    }

    printf("%c\n", *(arr[1] + 3));
    // arr[1]==A
    printf("%c\n", arr[1][3]);
}

void test04()
{
    int arr[5] = {10, 20, 30, 40, 50};
    int(*p)[5];

    // p自身的类型为:int (*)[5];
    printf("%lu\n", sizeof(p)); // 8B
    // p指向的类型为：int [5];
    printf("%lu\n", p);
    printf("%lu\n", p + 1);

    // 数组指针变量本质 其实就是保存数组的首地址
    p = &arr;

    printf("%d\n", *(*p + 2));//30
}

void test05()
{
    int arr[3][4]={1,2,3,4,5,6,7,8,9,10,11,12};
}
int main(int argc, char const *argv[])
{
    test05();
    return 0;
}
