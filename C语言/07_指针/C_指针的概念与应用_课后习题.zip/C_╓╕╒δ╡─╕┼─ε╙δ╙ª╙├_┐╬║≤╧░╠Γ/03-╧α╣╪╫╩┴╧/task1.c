#include <stdio.h>

void swap(int *a,int *b)
{
	*a = *a^*b;
	*b = *a^*b;
	*a = *a^*b;	
}
void func(signed int *p,int size)
{
	int i,j,tmp = 0;
	
	for(j=0;j<10;j++)
		for(i=0;i<10;i++){
			if(p[i] != 0)
				tmp = i;	
			else if(tmp<i)
				swap(&p[tmp],&p[i]);
		}
}
void main()
{
	int i;
	signed int arr[10] = {1,0,3,4,0,-5,6,0,7,-8};
	
	func(arr,10);
	for(i=0;i<10;i++)
		printf("%d ",arr[i]);
	printf("\n");
}