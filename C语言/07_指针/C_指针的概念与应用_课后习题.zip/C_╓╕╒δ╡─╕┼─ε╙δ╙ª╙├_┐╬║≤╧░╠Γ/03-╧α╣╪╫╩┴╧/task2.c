#include <stdio.h>
int main()
{
	char str[] = "char int long float";
	char *pstr[4],*p;
	int i=0;
	
	p = str;
	pstr[i++] = p;
	while(*p != '\0'){
		if(*p++ == ' '){
			*(p-1) = '\0';
			pstr[i++] = p;
		}
	}
	for(i=0;i<4;i++)
		printf("%s\n",pstr[i]);
	return 0;
}