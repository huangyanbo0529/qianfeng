#include <stdio.h>
#include <stdlib.h>
int main(int argc, char const *argv[])
{
    int *p = (int *)malloc(sizeof(int));
    *p = 1000;
    if (p != NULL)
    {
        free(p);//free释放的是p保存的地址编号对应的空间 不是p变量本身的空间
        p = NULL;
    }

    if (p != NULL)
    {
        free(p);
        p = NULL;
    }

    return 0;
}
