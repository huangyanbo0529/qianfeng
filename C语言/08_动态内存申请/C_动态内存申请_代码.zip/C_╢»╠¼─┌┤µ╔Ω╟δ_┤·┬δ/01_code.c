#include <stdio.h>
#include <stdlib.h>
int main(int argc, char const *argv[])
{
    int old_n = 0;
    printf("请输入旧空间的元素个数:");
    scanf("%d", &old_n);

    // 根据old_n申请堆区空间
    int *arr = (int *)calloc(old_n, sizeof(int));
    if (NULL == arr)
    {
        printf("calloc error\n");
        return 0;
    }

    // 获取键盘输入
    printf("请输入%d个int数值:", old_n);
    int i = 0;
    for (i = 0; i < old_n; i++)
    {
        scanf("%d", arr + i);
    }

    int new_n = 0;
    printf("请输入新增的元素个数:");
    scanf("%d", &new_n);

    // 为新增的元素个数追加空间
    arr = (int *)realloc(arr, (old_n + new_n) * sizeof(int));
    if (NULL == arr)
    {
        printf("realloc error\n");
        return 0;
    }

    // 为新增的空间输入元素
    printf("请输入%d个新增的int数据:", new_n);
    for (i = old_n; i < (old_n + new_n); i++)
    {
        scanf("%d", arr + i);
    }

    // 遍历整个数组
    for (i = 0; i < old_n + new_n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // 释放空间
    free(arr);

    return 0;
}
