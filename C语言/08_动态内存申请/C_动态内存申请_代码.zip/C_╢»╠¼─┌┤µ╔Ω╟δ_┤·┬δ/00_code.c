#include <stdio.h>
#include <stdlib.h>
void test01()
{
    // 1、申请一个int空间
    int *p1 = (int *)malloc(sizeof(int));
    if (NULL == p1)
    {
        printf("malloc error");
        return;
    }

    // 2、使用空间
    //*p1 = 1000;
    printf("%d\n", *p1);

    // 3、释放空间
    free(p1);
}

void test02()
{
    int n = 0;
    printf("请输入int数据的个数:");
    scanf("%d", &n);

    // 申请int数组空间
    int *arr = (int *)malloc(n * sizeof(int));
    if (NULL == arr)
    {
        printf("malloc error");
        return;
    }

    // 使用数组
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // printf("%d ", *(arr+i));
        printf("%d ", arr[i]);
    }
    printf("\n");

    // 释放空间
    free(arr);
}
void test03()
{
    int n = 0;
    printf("请输入int数据的个数:");
    scanf("%d", &n);

    // 申请int数组空间
    // int *arr = (int *)malloc(n*sizeof(int));
    int *arr = (int *)calloc(n, sizeof(int));
    if (NULL == arr)
    {
        printf("calloc error");
        return;
    }

    // 使用数组
    int i = 0;
    for (i = 0; i < n; i++)
    {
        // printf("%d ", *(arr+i));
        printf("%d ", arr[i]);
    }
    printf("\n");

    // 释放空间
    free(arr);
}

void test04()
{
    // 申请旧空间大小
    int *arr = (int *)calloc(5, sizeof(int));
    if (NULL == arr)
    {
        printf("calloc error");
        return;
    }

    // 追加新空间
    arr = (int *)realloc(arr, (5 + 5) * sizeof(int));
    if (NULL == arr)
    {
        printf("calloc error");
        return;
    }

    int i = 0;
    for (i = 0; i < 10; i++)
    {
        // printf("%d ", *(arr+i));
        printf("%d ", arr[i]);
    }
    printf("\n");

    // 释放空间
    free(arr);
}

#include <string.h>
void test05()
{
    int arr1[5] = {10, 20, 30, 40, 50};
    int arr2[5];

    // 内存拷贝
    memcpy(arr2, arr1, sizeof(arr1));

    int i = 0;
    for (i = 0; i < 5; i++)
    {
        printf("%d ", arr2[i]);
    }
    printf("\n");
}
int main(int argc, char const *argv[])
{
    test05();
    return 0;
}
