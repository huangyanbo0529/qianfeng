#include<stdio.h>
void test01()
{
	char buf1[128]="hello";
	char buf2[128]="workd";
	
	//逐个元素比较 相等才比较下一个  完全相等才相等
	int i=01;
	int flag = 0;
	while(  !(flag = buf1[i]-buf2[i])  && buf1[i] && ++i );
	
	if(flag > 0)
	{
		printf("%s 大于 %s\n",buf1,buf2);
	}
	else if(flag < 0)
	{
		printf("%s 小于 %s\n",buf1,buf2);
	}
	else if(flag == 0)
	{
		printf("%s 相等 %s\n",buf1,buf2);
	}
}
#include<string.h>
void test02()
{
	char buf[128]="";
	printf("请输入一个字符串:");
	fgets(buf,sizeof(buf),stdin);
	buf[strlen(buf)-1]='\0';
	
	//判断是否是回文
	//将end定位到尾元素
	int end=0;
	while(buf[end] && ++end);
	--end;
	
	//首尾元素 相等才比较下一个
	int i=0;
	while(buf[i]==buf[end])
	{
		i++;
		end--;
		if(i>=end)
			break;
	}
	
	if(i>=end)
	{
		printf("%s是回文\n",buf);
	}
	else
	{
		printf("%s不是回文\n",buf);
	}
	
}

void test03()
{
	char buf1[128]="";
	printf("请输入一个字符串:");
	fgets(buf1,sizeof(buf1),stdin);
	buf1[strlen(buf1)-1]='\0';
	
	//得到buf1的字符串长度
	int n=0;
	while(buf1[n] && ++n);
	
	printf("请输入插入的位置:");
	int pos = 0;
	scanf("%d",&pos);
	//去掉缓冲区回车
	getchar();
	
	//判断pos的合法
	if(pos <0 || pos > n)
	{
		printf("位置%d不合法\n",pos);
		return;
	}
	
	char buf2[128]="";
	printf("请输入一个字符串:");
	fgets(buf2,sizeof(buf2),stdin);
	buf2[strlen(buf2)-1]='\0';
	
	//得到buf2的长度
	int len = 0;
	while(buf2[len] && ++len);
	
	//buf1预留len的空间
	int i=0;
	for(i=n; i>=pos; i--)
	{
		buf1[i+len] = buf1[i];
	}
	
	//将buf2逐个元素 放入buf1的预留位置
	i=0;
	while(buf2[i] != '\0')
	{
		buf1[pos] = buf2[i];
		i++;
		pos++;
	}
	
	printf("插入后的结果:%s\n", buf1);
}

void test04()
{
	//初始化(连续初始化)
	//char buf[5][128]={'h','e','l','l','o'};
	//初始化(分段初始化)
	//char buf[5][128]={{'h','e'},{'l','l'}};
	//初始化(推荐，每一行以字符串的方式初始化)
	char buf[5][128]={"hello","world","xixi","hehehe","hahaha"};
	int row = sizeof(buf)/sizeof(buf[0]);
	int i=0;
	for(i=0;i<row;i++)
	{
		printf("%s\n",buf[i]);
	}
	
	printf("%c\n",buf[2][1]);
}

void test05()
{
	char buf[5][128]={""};
	int row = sizeof(buf)/sizeof(buf[0]);
	
	printf("请输入%d个字符串\n",row);
	int i=0;
	for(i=0;i<row;i++)
	{
		//scanf("%s", buf[i]);
		fgets(buf[i],sizeof(buf[i]),stdin);
	}
	for(i=0;i<row;i++)
	{
		printf("----%s\n", buf[i]);
	}
	
	
}
int main(int argc,char *argv[])
{
	test05();
	return 0;
}