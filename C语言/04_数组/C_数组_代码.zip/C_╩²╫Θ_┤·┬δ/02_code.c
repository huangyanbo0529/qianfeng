#include<stdio.h>
void test01()
{
	//连续初始化（全部初始化）
	int arr[3][4]={1,2,3,4,5,6,7,8,9,10,11,12};
	//如果是全部初始化 可以省略二维数组的行数
	//int arr[][4]={1,2,3,4,5,6,7,8,9,10,11,12};
	//int arr[3][4]={1,2,5,9};
	
	int row = sizeof(arr)/sizeof(arr[0]);
	int col = sizeof(arr[0])/sizeof(arr[0][0]);
	
	int i=0;
	for(i=0;i<row;i++)
	{
		int j=0;
		for(j=0;j<col;j++)
		{
			printf("%d ", arr[i][j]);	
		}
		printf("\n");
	}
}

void test02()
{
	int arr[5][4]={0};
	int row = sizeof(arr)/sizeof(arr[0]);
	int col = sizeof(arr[0])/sizeof(arr[0][0]);
	
	printf("请输入%d个int数值:",row*col);
	int i=0,j=0;
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d", &arr[i][j]);
		}
	}
	

	float avg[5]={0};
	for(i=0;i<row;i++)
	{
		//sum求一行的总和
		int sum = 0;
		for(j=0;j<col;j++)
		{
			sum+=arr[i][j];
		}
		avg[i] = (float)sum/col;
	}
	
	for(i=0;i<row;i++)
	{
		printf("%.2f ", avg[i]);
	}
	printf("\n");
}
int main(int argc,char *argv[])
{
	test02();
	return 0;
}
