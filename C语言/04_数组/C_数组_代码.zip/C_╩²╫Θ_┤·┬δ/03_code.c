#include<stdio.h>
void test01()
{
	//逐个字符初始化（不推荐）
	char buf1[]={'h','e','l','l','0'};//5B
	//以字符串"hello"的形式初始化一个字符数组 编译器会默认添加一个'\0'
	char buf2[]="hello";//6B

	printf("sizeof(buf1)=%ld\n",sizeof(buf1));
	printf("sizeof(buf2)=%ld\n",sizeof(buf2));
	
}

void test02()
{
	//以字符串的方式初始化 字符串的末尾默认有'\0'
	char buf[128]="hello world";
	
	//逐个字符遍历(需要遍历很多无效的数据)
	int i=0;
	for(i=0;i<128;i++)
	{
		printf("%c", buf[i]);
	}
	printf("\n");
	
	
	//逐个元素遍历 遇到'\0'自动结束遍历 如果需要逐个元素操作（遍历、拷贝、查询、追加）
	i=0;
	while(buf[i] != '\0')
	{
		printf("%c",buf[i]);
		i++;
	}
	printf("\n");
	
	//%s遍历一个字符串 遇到'\0'自动结束输出 %s需要的是字符串的首元素地址（背）(推荐)
	printf("%s\n",buf);
}
void test03()
{
	char buf1[128]="hello world";
	printf("%s\n",buf1);//hello world
	
	char buf2[128]="hello\0world";
	printf("%s\n",buf2);//hello
	
	char buf3[128]="\0hello\0world";
	printf("%s\n",buf3);//无输出
	
	int i=0;
	for(i=0;i<128;i++)
	{
		printf("%c", buf3[i]);
	}
	printf("\n");
	
	//如果只是查看字符串的内容可以选择%s
	//如果需要逐个元素操作字符 遇到'\0'结束 while(buf[i] !='\0')
	//如果希望遍历字符数组每个元素，不管是不是'\0',需要用for
}

void test04()
{
	char buf[128]="hello world";
	
	printf("%d %c\n", buf[4], buf[4]);//111 o
	buf[8] = buf[8]-32;
	
	printf("%s\n",buf);//hello woRld
	
	printf("%s\n", &buf[2]);//llo world
}

void test05()
{
	//可以将整个字符数组初始化为0
	char buf[128]="";
	
	printf("请输入一个字符串:");
	//%s获取字符串 遇到空格、回车自动结束  %s不能获取带空格的字符串
	scanf("%s", buf);
	
	printf("%s\n",buf);
}

void test06()
{
	//可以将整个字符数组初始化为0
	char buf[6]="";
	
	printf("请输入一个字符串:");
	//gets获取带空格的字符串 放入buf中
	//gets 获取字符串的时候 不会判断存储空间是否越界 很容易访问非法内存
	gets(buf);//危险
	
	printf("##%s##\n",buf);
}

#include<string.h>
void test07()
{
	//可以将整个字符数组初始化为0
	char buf[128]="";
	
	printf("请输入一个字符串:");
	//能获取带空格的字符串，遇到换行符结束 但是要获取换行符
	fgets(buf,sizeof(buf), stdin);
	buf[strlen(buf)-1]=0;
	
	printf("##%s##\n",buf);
}

void test08()
{
	char buf[128]="hello world";
	printf("%ld\n",sizeof(buf));//128
	printf("%d\n", strlen(buf));//11
	
	char buf1[]="hello world";
	printf("%ld\n",sizeof(buf1));//12
	printf("%d\n", strlen(buf1));//11
	
	char buf2[]="hello\0world";
	printf("%ld\n",sizeof(buf2));//12
	printf("%d\n", strlen(buf2));//5
	
	char buf3[]={'h','e','l','l','o'};
	printf("%ld\n",sizeof(buf3));//5
	printf("%d\n", strlen(buf3));//未知
}

void test09()
{
	char buf[]="hello\xabcde\xfgworld";
	printf("%ld\n",sizeof(buf));//14
	printf("%d\n", strlen(buf));//13
}

void test10()
{
	
	char buf[]="%%hello\r\\123\x128\578\cbc";
	printf("%ld\n",sizeof(buf));//19
	printf("%d\n", strlen(buf));//18
}

void test11()
{
	char buf[128]="";
	printf("请输入一个字符串:");
	fgets(buf,sizeof(buf),stdin);
	buf[strlen(buf)-1]='\0';
	
	int len=0;
	while(buf[len] != '\0')
		len++;
	printf("len=%d\n",len);
}

void test12()
{
	char buf1[128]="";
	printf("请输入一个字符串:");
	fgets(buf1,sizeof(buf1),stdin);
	buf1[strlen(buf1)-1]='\0';
	
	char buf2[128]="";
	
	int i=0;
	while((buf2[i] = buf1[i]) && ++i);
	
	buf2[i]='\0';
	
	printf("buf2=%s\n",buf2);
	
}

void test13()
{
	char buf1[128]="";
	printf("请输入一个字符串:");
	fgets(buf1,sizeof(buf1),stdin);
	buf1[strlen(buf1)-1]='\0';
	
	char buf2[128]="";
	printf("请输入一个字符串:");
	fgets(buf2,sizeof(buf2),stdin);
	buf2[strlen(buf2)-1]='\0';
	
	//定位buf1的尾部
	int end=0;
	while(buf1[end]!='\0')
		end++;
	
	//将buf2的逐个元素 赋值到buf1的尾部之后
	int i=0;
	while(buf2[i] != '\0')
	{
		buf1[end]=buf2[i];
		end++;
		i++;
	}
	buf1[end]='\0';
	
	printf("buf1=%s\n",buf1);
}
int main(int argc,char *argv[])
{
	test13();
	return 0;
}
