#include<stdio.h>

void test01()
{
	int i=3;
	//i++;
	++i;
	printf("i=%d\n",i);//4
}
void test02()
{
	int i=3;
	int j=0;
	j=i++;//j=i; i=i+1;
	printf("i=%d, j=%d\n",i,j);//i=4 j=3
	
}
void test03()
{
	int a=10;
	a=a++;//将a的值赋值给a  后面的自增语句失效 所以a=10
	printf("a=%d\n",a);//10
}

int main(int argc,char *argv[])
{
	test03();
	return 0;
}
