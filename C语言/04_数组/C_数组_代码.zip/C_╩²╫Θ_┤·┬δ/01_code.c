#include<stdio.h>
void test01()
{
	//一维数值数组 局部数组不初始化 元素内容不确定
	int arr[5];
	//定义数组的时候  []里面不能有变量比如：int n=5;  int arr[n];
	//数组的下标范围：0~4   (背)
	//数组的元素范围：arr[0]~arr[4]  （背）
	
	//数组名都是符号常量 不能被赋值（记）
	//arr=100;//error
	
	//sizeof测量类型的大小
	//数组名作为类型 需要和sizeof结合：sizeof(arr) == 数组的总大小 == 数组元素的个数*每个元素的大小
	//数组名作为类型代表的是数组的总大小（记）
	printf("%ld\n",sizeof(arr));//20
	
	//数组元素的个数 = sizeof(arr)/sizeof(arr[0])  (记)
	int n = sizeof(arr)/sizeof(arr[0]);
	printf("n=%d\n", n);
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
}
void test02()
{
	//全部初始化
	//int arr[5]={10,20,30,40,50};
	//如果全部初始化 可以省略元素个数 
	//数组元素的个数 由初始化个数决定
	//int arr[]={10,20,30,40,50}; 
	
	//部分初始化: 未被初始化的部分自动补0
	//int arr[5]={10,20,30};//10 20 30 0 0
	//int arr[5]={0};//推荐：将第0个元素初始化为0 其他未被初始化自动补0 所以大家都为0
	int arr[5]={[1]=30, [3]=40};//0 30 0 40 0将第1个元素初始化为30 第3个元素初始化为40

	int n = sizeof(arr)/sizeof(arr[0]);
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
}

void test03()
{
	int arr[5]={0};
	int n = sizeof(arr)/sizeof(arr[0]);
	
	//数组的每个元素 等价 普通变量
	//num=100
	arr[0]=100;
	//num++
	arr[0]++;//arr[0]=arr[0]+1
	//data=num
	arr[1]=arr[0];
	
	//scanf("%d", &num)
	scanf("%d", &arr[2]);
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
	
}

void test04()
{
	int arr[5]={0};
	int n = sizeof(arr)/sizeof(arr[0]);
	
	printf("请输入%d个int数据:", n);
	int i=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);//默认每个数据以空格隔开
	}
	
	int sum=0;
	for(i=0;i<n;i++)
	{
		sum+=arr[i];
	}
	printf("数组元素的综合为:%d\n", sum);
	
}
int main(int argc,char *argv[])
{
	test04();
	return 0;
}
