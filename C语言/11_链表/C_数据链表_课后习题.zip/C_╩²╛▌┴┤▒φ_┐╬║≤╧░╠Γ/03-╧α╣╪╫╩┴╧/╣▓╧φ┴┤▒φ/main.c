#include <stdio.h>
#include <stdlib.h>

struct STU{
	char name[20];
	int height;
	int weight;
	char sex;
	struct STU *next;
};

struct STU *list_create(int num)
{
	struct STU *head = NULL;
	struct STU *node = NULL;
	struct STU *mov = NULL;
	int i;

	for(i=0; i<num; i++)
	{
		node = (struct STU *)malloc(sizeof(*node));
		printf("���������������ߣ����أ�\n");
		scanf("%s %d %d",node->name,&node->height,&node->weight);

		if(!head)
			mov = head = node;
		else{
			mov->next = node;
			mov = node;
		}	
		node->next = NULL;
	}
	return head;
}

struct STU *list_insert(struct STU *head, struct STU *new)
{
	struct STU *mov = head;
	struct STU *last = head;

	while(mov)
	{
		if(mov->height > new->height)
			break;
		last = mov;
		mov = mov->next;
	}

	if(mov == head){
		head = new;
		new->next = mov;		
	}else if(mov == NULL){
		last->next = new;
		new->next = NULL;
	}else{
		last->next = new;
		new->next = mov;
	}
	return head;
}

void list_free(struct STU *head)
{
	struct STU *mov = head;
	//�ͷ�����
	while(mov)
	{
		head = head->next;
		free(mov);
		mov = head;
	}
	return;
}

void list_print(struct STU *head)
{
	struct STU *mov = head;
	
	while(mov)
	{
		printf("node message: %s %d %d\n",
			mov->name,mov->height,mov->weight);
		mov = mov->next;
	}
	return;
}

struct STU *list_search(struct STU *head, int hgt)
{
	struct STU *mov = head;
	while(mov)
	{
		if(mov->height == hgt)
			return mov;
		mov = mov->next;
	}

	return NULL;
}

struct STU student[] = {
	{"yabin",155,65},
	{"liujie",165,50},
	{"haoyu",170,70},
	{"xiaowu",175,65},
	{"xiening",180,60},
	{"hanbiao",185,55},
};

struct STU onestu = {"xiangshuai",200,80};

int main(void)
{
	struct STU *head = NULL;
	struct STU *node;
	int i;
	//��������
	//head = list_create(6);
	for(i=0; i<sizeof(student)/sizeof(student[0]); i++)
		head = list_insert(head,&student[i]);

	//��ӡ����
	list_print(head);
	printf("--------------\n");
	head = list_insert(head, &onestu);
	list_print(head);
	
	node = list_search(head, 155);
	if(node == NULL)
		printf("search failed!\n");
	else
		printf("name: %s, height: %d, weight %d\n",
				node->name, node->height, node->weight);

	//�ͷ�����
//	list_free(head);


	return 0;
}
