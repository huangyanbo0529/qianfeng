#include <stdio.h>
#include <stdlib.h>
typedef struct stu
{
    // 数据域
    int num;
    char name[32];
    float score;

    // 指针域
    struct stu *next;
    struct stu *pre;
} STU;
STU *insert_double_link(STU *head, STU tmp);
void print_double_link(STU *head);
STU *search_double_link(STU *head, int num);
STU *delete_double_link(STU *head, int num);

STU *head = NULL;
int main(int argc, char const *argv[])
{
    int n = 0;
    printf("请输入学员的个数:");
    scanf("%d", &n);

    int i = 0;
    for (i = 0; i < n; i++)
    {
        printf("请输入第%d个学员的信息num name score:", i + 1);
        STU tmp;
        scanf("%d %s %f", &tmp.num, tmp.name, &tmp.score);
        head = insert_double_link(head, tmp);
    }

    // 遍历链表
    print_double_link(head);

    // 查找指定节点
    printf("请输入需要查找的学号:");
    int num = 0;
    scanf("%d", &num);

    STU *ret = search_double_link(head, num);
    if (ret != NULL)
    {
        printf("查询结果:%d %s %f\n", ret->num, ret->name, ret->score);
    }

    // 删除指定节点
    printf("请输入需要删除的学号:");
    scanf("%d", &num);
    head = delete_double_link(head, num);

    // 遍历链表
    print_double_link(head);

    return 0;
}
STU *insert_double_link(STU *head, STU tmp)
{
    // 1、为插入的节点申请堆区空间
    STU *pi = (STU *)malloc(sizeof(STU));
    if (NULL == pi)
    {
        printf("malloc error\n");
        return head;
    }

    // 2、将tmp的值 赋值给*pi
    *pi = tmp;

    // 判断链表是否存在
    if (NULL == head)
    {
        head = pi;
        head->next = head;
        head->pre = head;
        return head;
    }
    else
    {
        head->pre->next = pi;
        pi->next = head;
        pi->pre = head->pre;
        head->pre = pi;
    }
    return head;
}
void print_double_link(STU *head)
{
    // 判断链表是否存在
    if (head == NULL)
    {
        printf("link not exist\n");
        return;
    }
    else
    {
        STU *pn = head;      // 在头节点
        STU *pr = head->pre; // 在尾节点
        while (1)
        {
            if (pn == pr) // 奇数个节点
            {
                printf("%d %s %f\n", pn->num, pn->name, pn->score);
                break;
            }
            else if (pn->next == pr) // 偶数个节点
            {
                printf("%d %s %f\n", pn->num, pn->name, pn->score);
                printf("%d %s %f\n", pr->num, pr->name, pr->score);
                break;
            }

            printf("%d %s %f\n", pn->num, pn->name, pn->score);
            printf("%d %s %f\n", pr->num, pr->name, pr->score);

            pn = pn->next;
            pr = pr->pre;
        }
    }
}

STU *search_double_link(STU *head, int num)
{
    if (head == NULL)
    {
        printf("link not exist\n");
        return NULL;
    }
    else
    {
        STU *pn = head;
        STU *pr = head->pre;

        while ((pn->num != num) && (pr->num != num) && (pn != pr) && (pn->next != pr))
        {
            pn = pn->next;
            pr = pr->pre;
        }

        if (pn->num == num)
        {
            return pn;
        }
        else if (pr->num == num)
        {
            return pr;
        }
        else
        {
            printf("未找到相关节点\n");
        }
    }
    return NULL;
}
STU *delete_double_link(STU *head, int num)
{
    if (head == NULL)
    {
        printf("link not exist\n");
        return NULL;
    }
    else
    {
        STU *pn = head;
        STU *pr = head->pre;

        while ((pn->num != num) && (pr->num != num) && (pn != pr) && (pn->next != pr))
        {
            pn = pn->next;
            pr = pr->pre;
        }

        if (pn->num == num) // 头、中删除
        {
            if (pn == head) // 头
            {
                head = head->next;
                pn->pre->next = head;
                head->pre = pn->pre;
                free(pn);
            }
            else // 中
            {
                pn->pre->next = pn->next;
                pn->next->pre = pn->pre;
                free(pn);
            }
            printf("删除指定节点\n");
        }
        else if (pr->num == num) // 中、尾删除
        {
            pr->pre->next = pr->next;
            pr->next->pre = pr->pre;
            free(pr);
            printf("删除指定节点\n");
        }
    }
    return head;
}