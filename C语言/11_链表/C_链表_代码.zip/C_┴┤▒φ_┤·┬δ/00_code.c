#include <stdio.h>
typedef struct stu
{
    // 数据域
    int num;
    char name[32];
    float score;

    // 指针域
    struct stu *next;
} STU;

int main(int argc, char const *argv[])
{
    // 局部节点
    STU node1 = {101, "lucy", 99.9f, NULL};
    STU node2 = {102, "bob", 99.9f, NULL};
    STU node3 = {103, "tom", 99.9f, NULL};
    STU node4 = {104, "德玛", 99.9f, NULL};
    STU node5 = {105, "小炮", 99.9f, NULL};

    // 定义一个链表头
    STU *head = &node1;
    node1.next = &node2;
    node2.next = &node3;
    node3.next = &node4;
    node4.next = &node5;

    // 遍历一个链表
    STU *pb = head;
    while (pb != NULL)
    {
        printf("%d %s %f\n", pb->num, pb->name, pb->score);
        pb = pb->next; // 指向下一个节点
    }
    return 0;
}
