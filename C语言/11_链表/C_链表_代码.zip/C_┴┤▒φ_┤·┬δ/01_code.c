#include <stdio.h>
#include <string.h>
#include "link.h"
void help(void)
{
    printf("*************************************\n");
    printf("*insert:插入链表节点                *\n");
    printf("*print:遍历链表                     *\n");
    printf("*search:查询链表的某个节点          *\n");
    printf("*delete:删除链表的某个节点          *\n");
    printf("*free:释放整个链表                  *\n");
    printf("*quit:退出整个进程                  *\n");
    printf("*reverse:链表逆序                   *\n");
    printf("*sort:链表排序                      *\n");
    printf("*************************************\n");
    return;
}
int main(int argc, char const *argv[])
{
    //定义一个链表头
    STU *head=NULL;

    help();

    while (1)
    {
        printf("请输入操作指令:");
        char cmd[32] = "";
        scanf("%s", cmd);

        if (strcmp(cmd, "insert") == 0)
        {
            printf("请输入num name score:");
            STU tmp;//暂时获取学生信息
            scanf("%d %s %f", &tmp.num, tmp.name, &tmp.score);

            //调用链表插入函数
            head = insert_link(head,tmp);
        }
        else if (strcmp(cmd, "print") == 0)
        {
            print_link(head);
        }
        else if (strcmp(cmd, "search") == 0)
        {
            printf("请输入需要查询的姓名:");
            char name[32]="";
            scanf("%s",name);

            STU *ret = search_link(head,name);
            if(ret != NULL)//找到
            {
                printf("查询的结果:%d %s %f\n", ret->num, ret->name,ret->score);
            }
        }
        else if (strcmp(cmd, "delete") == 0)
        {
            printf("请输入需要删除的序号:");
            int num = 0;
            scanf("%d", &num);

            head = delete_link(head,num);
        }
        else if (strcmp(cmd, "free") == 0)
        {
            head = free_link(head);
        }
        else if (strcmp(cmd, "quit") == 0)
        {
            head = free_link(head);
            return 0;
        }
        else if (strcmp(cmd, "reverse") == 0)
        {
            head = reverse_link(head);
        }
        else if (strcmp(cmd, "sort") == 0)
        {
            sort_link(head);
        }
    }

    return 0;
}
