#include <stdio.h>
void sort_int_array01(int *arr, int n)
{
    int i = 0;
    for (i = 0; i < n - 1; i++)
    {
        int j = 0;
        for (j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
            }
        }
    }
    return;
}
void sort_int_array02(int *arr, int n)
{
    int i = 0;
    for (i = 0; i < n - 1; i++)
    {
        int min, j;
        // 寻找最小值的下标
        for (min = i, j = min + 1; j < n; j++)
        {
            if (arr[min] > arr[j])
                min = j;
        }

        if (min != i)
        {
            int tmp = arr[i];
            arr[i] = arr[min];
            arr[min] = tmp;
        }
    }
}
int main(int argc, char const *argv[])
{
    int arr[10] = {0};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("请输入%d个int数值:", n);
    int i = 0;
    for (i = 0; i < n; i++)
    {
        scanf("%d", arr + i);
    }

    // 排序
    // sort_int_array01(arr, n);
    sort_int_array02(arr, n);

    for (i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}
