#include "link.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// 插入链表之 头部之前插入
#if 0
STU *insert_link(STU *head, STU tmp)
{
    // 1、为节点申请空间
    STU *pi = (STU *)malloc(sizeof(STU));
    if (NULL == pi)
    {
        printf("malloc\n");
        return head;
    }

    // 2、将键盘输入的tmp数据 赋值给 链表的pi节点
    *pi = tmp;
    pi->next = NULL;

    // 3、判断链表是否存在
    if (NULL == head)
    {
        // 如果链表不存在 那么pi就是链表的第一个节点 直接head保存pi的值即可
        head = pi;
        // return head;
    }
    else
    {
        pi->next = head; // pi将会是新的头节点  pi->next应该保存旧头节点的地址
        head = pi;       // 让head指向新的头节点
        // return head;
    }

    return head;
}
#endif

#if 0
//链表插入节点值尾部插入
STU *insert_link(STU *head, STU tmp)
{
    //1、为插入的数据申请堆区空间
    STU *pi = (STU *)malloc(sizeof(STU));
    if(NULL == pi)
    {
        printf("malloc\n");
        return head;
    }

    //2、将tmp数据 赋值给堆区空间 *pi
    *pi=tmp;
    pi->next =NULL;

    //3、判断链表是否存在
    if(NULL == head)//不存在
    {
        head=pi;
        return head;
    }
    else//存在
    {
        //4、寻找链表的尾部
        STU *pb= head;
        while(pb->next!=NULL)
            pb=pb->next;

        //5、在尾部 插入pi节点
        pb->next = pi;
    }

    return head;
}
#endif
// 链表插入节点有序插入
STU *insert_link(STU *head, STU tmp)
{
    // 1、为插入的数据申请堆区空间
    STU *pi = (STU *)malloc(sizeof(STU));
    if (NULL == pi)
    {
        printf("malloc\n");
        return head;
    }

    // 2、将tmp数据 赋值给堆区空间 *pi
    *pi = tmp;
    pi->next = NULL;

    // 3、判断链表是否存在
    if (NULL == head) // 不存在
    {
        head = pi;
        return head;
    }
    else // 存在
    {
        // 4、寻找插入点
        STU *pf = head, *pb = head;
        while ((pb->num < pi->num) && (pb->next != NULL))
        {
            pf = pb;
            pb = pb->next;
        }

        // 5、判断插入点是头、中、尾
        if (pb->num >= pi->num) // 头部 中部插入
        {
            if (pb == head) // 头部
            {
                pi->next = head;
                head = pi;
            }
            else // 中部
            {
                pf->next = pi;
                pi->next = pb;
            }
        }
        else // 尾部插入
        {
            pb->next = pi;
        }
    }

    return head;
}

void print_link(STU *head)
{
    // 1、判断链表是否存在
    if (NULL == head)
    {
        printf("link not found\n");
        return;
    }
    else
    {
        STU *pb = head;    // 定义一个pb指针变量 指向头节点
        while (pb != NULL) // 逐个节点访问
        {
            // 遍历pb指向的节点
            printf("%d %s %f\n", pb->num, pb->name, pb->score);
            // pb移动到下一个节点
            pb = pb->next;
        }
    }
    return;
}

STU *search_link(STU *head, char *name)
{
    // 1、判断链表是否存在
    if (NULL == head)
    {
        printf("link not exits\n");
        return NULL;
    }
    else
    {
        // 逐个节点查询
        STU *pb = head;
        while ((strcmp(pb->name, name) != 0) && (pb->next != NULL))
            pb = pb->next;

        if (strcmp(pb->name, name) == 0)
            return pb;
        else
            printf("not found\n");
    }

    return NULL;
}

STU *delete_link(STU *head, int num)
{
    // 判断链表是否存在
    if (NULL == head)
    {
        printf("link not exist\n");
        return head;
    }
    else
    {
        // 逐个节点寻找
        STU *pf = head, *pb = head;
        while ((pb->num != num) && (pb->next != NULL))
        {
            pf = pb;
            pb = pb->next;
        }

        // 判断删除点的位置
        if (pb->num == num) // 找到
        {
            if (pb == head) // 删除头部节点
            {
                head = head->next;
            }
            else // 删除中尾部节点
            {
                pf->next = pb->next;
            }
            // 释放pb
            free(pb);

            printf("相应节点成功删除\n");
        }
        else
        {
            printf("未找到num=%d的相关节点\n", num);
        }
    }
    return head;
}
STU *free_link(STU *head)
{
    // 判断链表是否存在
    if (NULL == head)
    {
        printf("link not exist\n");
        return head;
    }
    else
    {
        // 逐个节点释放
        STU *pb = head;
        while (pb != NULL)
        {
            // 纪录下一个节点位置
            head = head->next;
            // 释放pb
            free(pb);
            // 让pb指向head
            pb = head;
        }
        printf("整个链表释放完毕\n");
    }

    return NULL;
}

STU *reverse_link(STU *head)
{
    // 判断链表是否存在
    if (NULL == head)
    {
        printf("link not exist\n");
        return head;
    }
    else
    {
        STU *pb, *pf;

        // 需要将head->next置NULL 所以需要pb纪录head->next
        pb = head->next;
        // 将head->next置NULL
        head->next = NULL;

        // 逐个节点反向指向
        while (pb != NULL)
        {
            // 需要将pb->next指向前一个节点 需要pf纪录下一个节点的位置
            pf = pb->next;
            // pb的next指向前一个
            pb->next = head;
            // 移动head到pb
            head = pb;
            // pb移动到pf处
            pb = pf;
        }
        printf("链表逆序成功\n");
    }

    return head;
}

void sort_link(STU *head)
{
    // 判断链表是否存在
    if (NULL == head)
    {
        printf("link not exist\n");
        return;
    }
    else
    {
        // int i = 0;
        STU *p_i = NULL;

        // for ( i = 0; i < n-1; i++)
        for (p_i = head; p_i->next != NULL; p_i = p_i->next)
        {
            // int min, j;
            STU *p_min, *p_j;
            // 寻找最小值的下标
            // for (min = i, j = min + 1; j < n; j++)
            for (p_min = p_i, p_j = p_min->next; p_j != NULL; p_j = p_j->next)
            {
                // if (arr[min] > arr[j])
                if (p_min->num > p_j->num)
                {
                    // min = j;
                    p_min = p_j;
                }
            }

            // if (min != i)
            if (p_min != p_i)
            {
                // int tmp = arr[i];
                // arr[i] = arr[min];
                // arr[min] = tmp;
                STU tmp = *p_min;
                *p_min = *p_i;
                *p_i = tmp;

                tmp.next = p_min->next;
                p_min->next = p_i->next;
                p_i->next = tmp.next;
            }
        }
        printf("链表排序完成\n");
    }
}