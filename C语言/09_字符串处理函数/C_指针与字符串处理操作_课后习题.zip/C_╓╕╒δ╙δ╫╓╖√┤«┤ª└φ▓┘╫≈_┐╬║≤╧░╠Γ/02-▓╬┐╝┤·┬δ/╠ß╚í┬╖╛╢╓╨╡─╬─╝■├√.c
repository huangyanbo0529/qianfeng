#include <stdio.h>
#include <string.h>
int main()
{
	char buf[100]={0};
	char old[100]={0};
	char src[100] = "/Users/edu/test/tablet_cht/boot.img";

/* 方法一：已知路径深度 */
//	sscanf(src,"/%*[^//]/%*[^//]/%*[^//]/%*[^//]/%s",buf);

/* 方法二：路径深度未知 */	
	gets(src);
	sscanf(src,"/%*[^//]/%s",buf);
	if(buf[0] == 0)
		strcpy(buf,src+1);
	else
		while(1){
			strcpy(old,buf);/* 备份这一次截取的串 */
			sscanf(buf,"%*[^//]/%s",buf);/* 再一次截取 */
			if(strcmp(old,buf) == 0)/* 如果无法通过sscanf截取，说明已经不在变化 */
				break;
		}
	puts(buf);
	return 0;
}
