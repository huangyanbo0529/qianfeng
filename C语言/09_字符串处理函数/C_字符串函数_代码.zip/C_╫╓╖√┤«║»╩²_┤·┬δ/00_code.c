#include <stdio.h>
#include <string.h>
void test01()
{
    char *str = "hello world";
    printf("%ld\n", strlen(str)); // 11
}

void test02()
{
    char *src = "hel\0lo world";
    char dst[128] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    strncpy(dst, src, 5);
    int i = 0;
    for (i = 0; i < 128; i++)
    {
        printf("%d ", dst[i]);
    }
    printf("\n");
}

void test03()
{
    char dst[128] = "hello\0world";
    char *src = "xixi haha";

    strcat(dst, src);
    printf("dst=%s\n", dst);
}

void test04()
{
    char src[] = "hello";
    char dst[] = "haha";

    if (strcmp(src, dst) == 0)
    {
        printf("相等\n");
    }
    else if (strcmp(src, dst) > 0)
    {
        printf("大于\n");
    }
    else if (strcmp(src, dst) < 0)
    {
        printf("小于\n");
    }
}

void test05()
{
    char buf1[] = "pub:xxxxxxxxxxxxxxxx";
    if (strncmp(buf1, "pub", 3) == 0)
    {
        printf("%s是发布命令\n", buf1);
    }
}

void test06()
{
    char buf[] = "hello world";
    char *ret = strchr(buf, 'o');
    printf("%s\n", ret);
    *ret = ':';
    printf("%s\n", buf);
}

void test07()
{
    char buf[] = "http://www.sex.777.sex.999.sex.cn";
    char *ret = NULL;
    while (ret = strstr(buf, "sex"))
    {
        memset(ret, '*', strlen("sex"));
    }

    printf("%s\n", buf);
}
#include <stdlib.h>
void test08()
{
    printf("%d\n", atoi("1234"));
    printf("%ld\n", atol("1234"));
    printf("%f\n", atof("12.34"));
}

void test09()
{
    char str[] = "hehehe:xixixi:lalala:heiheihei:wuwuwu:henhenhenhen";
    char *buf[128] = {str, NULL};

    int i = 0;
    while ((buf[i] = strtok(buf[i], ":")) && ++i)
        ;

    i = 0;
    while (buf[i] != NULL)
    {
        printf("%s\n", buf[i]);
        i++;
    }
}
int msg_deal(char *msg_src, char *msg_done[], char *str)
{
    msg_done[0] = msg_src;

    int i = 0;
    while ((msg_done[i] = strtok(msg_done[i], str)) && ++i)
        ;

    return i;
}
void test10()
{
    char msg_src[] = "+CMGR:REC UNREAD,+8613466630259,98/10/01,18:22:11+00,ABCdefGHI";
    char *msg_done[128] = {NULL};

    int num = msg_deal(msg_src, msg_done, ",");
    printf("num=%d\n", num);

    printf("手机号:%s\n", msg_done[1] + 3);
    printf("日期:%s\n", msg_done[2]);
    char *ret = strchr(msg_done[3], '+');
    if (ret != NULL)
        *ret = '\0';
    printf("时间:%s\n", msg_done[3]);
    printf("内容:%s\n", msg_done[4]);
}
int main(int argc, char const *argv[])
{
    test10();
    return 0;
}
