#include <stdio.h>
void test01()
{
    int year = 2023;
    int month = 7;
    int day = 28;

    char buf[128] = "";
    int len = sprintf(buf, "%d年%d月%d日", year, month, day);
    printf("buf=%s\n", buf);
    printf("len=%d\n", len);
}
void test02()
{
    char buf[128] = "";
    sprintf(buf, "%d", 1234);
    printf("%s\n", buf);
}

void test03()
{
    char buf[128] = "hello world";
    char buf2[128] = "";

    sscanf(buf, "%s", buf2);
    printf("buf2=%s\n", buf2);
}
void test04()
{
    char buf[128] = "123abc456";
    int data = 0;

    sscanf(buf, "%d", &data);
    printf("data=%d\n", data);
}

void test05()
{
    char buf[128] = "123abc456";
    char ch;
    sscanf(buf, "%c", &ch);
    printf("ch=%c\n", ch);
}

void test06()
{
    char buf1[] = "helloworld";
    char buf2[32] = "";
    sscanf(buf1, "%5s", buf2);
    printf("buf2=%s\n", buf2); // hello

    char buf3[] = "12345678";
    int data = 0;
    sscanf(buf3, "%3d", &data);
    printf("data=%d\n", data);
}

void test07()
{
    char buf1[] = "helloworld";
    char buf2[32] = "";
    // sscanf(buf1, "%*2s%3s", buf2);
    sscanf(buf1, "%*c%*c%3s", buf2);
    printf("buf2=%s\n", buf2); // llo

    char buf3[] = "12345678";
    int data = 0;
    // sscanf(buf3, "%*3d%3d", &data);
    // sscanf(buf3, "%*3s%3d", &data);
    sscanf(buf3, "%*2s%*c%3d", &data);

    printf("data=%d\n", data);
}

void test08()
{
    // char buf[128] = "[02:16.33]我想大声宣布对你依依不舍";
    char buf[128] = "[02:16.33][04:11.44][05:11.44]我想大声宣布对你依依不舍";
    char *p_lrc = buf; // 让p_lrc定位歌词的位置

    // 定位歌词的位置
    while (*p_lrc == '[')
        p_lrc += 10;

    // 分析时间
    char *p_time = buf;
    while (*p_time == '[')
    {
        int m = 0, s = 0;
        sscanf(p_time, "[%d:%d", &m, &s);
        printf("%d秒打印歌词:%s\n", m * 60 + s, p_lrc);
        p_time += 10;
    }
}
int main(int argc, char const *argv[])
{
    test08();
    return 0;
}
