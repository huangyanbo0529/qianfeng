#include <stdio.h>
typedef int *P_TYPE1;
#define P_TYPE2 int *
void test01()
{
    P_TYPE1 p1, p2; // p1 p2都是int *类型的指针变量

    // int* p3,p4;
    P_TYPE2 p3, p4; // p3是int *类型的指针变量  p4是int类型变量

    printf("%ld\n", sizeof(p1));
    printf("%ld\n", sizeof(p2));
    printf("%ld\n", sizeof(p3));
    printf("%ld\n", sizeof(p4));
}

void test02()
{
    // ARR_TRPE就是数组类型 该数组必须5个元素 每个元素为int
    typedef int ARR_TRPE[5];
    ARR_TRPE arr;                 // arr为数组
    printf("%ld\n", sizeof(arr)); // 20
}


typedef int (*P_FUN)(int, int);
int my_add(int x, int y)
{
    return x + y;
}
int my_calc(int x, int y, P_FUN func)
{
    return func(x, y);
}
void test03()
{
    P_FUN p = my_add;
    printf("%d\n", my_calc(100, 200, my_add));
}
int main(int argc, char const *argv[])
{
    test03();
    return 0;
}
