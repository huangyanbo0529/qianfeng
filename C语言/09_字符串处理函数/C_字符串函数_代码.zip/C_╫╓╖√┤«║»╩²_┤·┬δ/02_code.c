#include <stdio.h>
void test01()
{
    // const 修饰data为只读 data本质还是变量
    const int data = 10;
    // data = 1000;//error
    int *p = (int *)&data;
    *p = 1000;
    printf("data=%d\n", data); // 1000
}

void test02()
{
    int data = 10;
    // const 修饰的*，不能对*p赋值  但是p可读可写
    const int *p = &data;
    //*p = 1000;//error
    printf("*p=%d\n", *p); // 10

    int num = 100;
    p = &num;
    printf("*p=%d\n", *p); // 100
}

void test03()
{
    int data = 10;
    // const 修饰的p   p只读  *p可读可写
    int *const p = &data;
    *p = 1000;
    printf("data=%d\n", data);

    int num = 100;
    // p = &num;//error
}
void test04()
{
    int data = 10;
    // p只读  *p只读
    const int *const p = &data;
    //*p = 1000;//error
    printf("data=%d\n", data);

    int num = 100;
    // p = &num; // error
}

void test05()
{
    // INT32就是int的别名
    typedef int INT32;
    int data1 = 10;
    INT32 data2 = 20;
    printf("data1=%d, data2=%d\n", data1, data2);
}
void test06()
{
    // 需求：给int *取个别名P_TYPE
    typedef int *P_TYPE; // P_TYPE==int *
    P_TYPE p;            // int *p
    int data = 10;
    p = &data;
    printf("*p=%d\n", *p);
}


int main(int argc, char const *argv[])
{
    test06();
    return 0;
}
