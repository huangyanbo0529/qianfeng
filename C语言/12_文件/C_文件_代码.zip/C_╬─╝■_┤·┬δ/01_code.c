#include <stdio.h>
#include <stdlib.h>
void get_file_name(char *dest_file_name, char *src_file_name);
char *read_src_file(unsigned long int *file_length, char *src_file_name);
char *file_text_encrypt(char *src_file_text, unsigned long int length, unsigned int password);
void save_file(char *text, unsigned long int length, char *file_name);
char *file_text_decrypt(char *src_file_text, unsigned long int length, unsigned int password);
void help()
{
    printf("********1:加密文件***********\n");
    printf("********2:解密文件***********\n");
    printf("********3:退出程序***********\n");
}
int main(int argc, char const *argv[])
{
    while (1)
    {
        char src_file[31] = "";
        char dst_file[31] = "";
        unsigned long int file_len = 0;
        char *data = NULL;
        unsigned int passwd = 0;

        help();
        int cmd = 0;
        scanf("%d", &cmd);

        switch (cmd)
        {
        case 1:
            get_file_name(dst_file, src_file);
            data = read_src_file(&file_len, src_file);
            printf("please input your unsigned int passworld:");
            scanf("%d", &passwd);
            data = file_text_encrypt(data, file_len, passwd);
            save_file(data, file_len, dst_file);
            break;
        case 2:
            get_file_name(dst_file, src_file);
            data = read_src_file(&file_len, src_file);
            printf("please input your unsigned int passworld:");
            scanf("%d", &passwd);
            data = file_text_decrypt(data, file_len, passwd);
            save_file(data, file_len, dst_file);
            break;
        case 3:
            return 0;

        default:
            break;
        }
    }

    return 0;
}
/**************************************************************************/
// 函数功能:获取 目的文件和源文件的名字
// 参数：
//   src_file_name:源文件名字字符数组首地址。
//   dest_file_name:目的文件的名字字符数组首地址
/**************************************************************************/
void get_file_name(char *dest_file_name, char *src_file_name)
{
    printf("请输入你的原文件名称(30个字符):");
    scanf("%s", src_file_name);
    printf("请输入你的目的文件名称(30个字符):");
    scanf("%s", dest_file_name);
    return;
}
/**************************************************************************/
// 函数功能:读出文件内容
// 参数：file_length:整型指针，此地址中保存文件字节数。
//  src_file_name:文件名字，从此文件中读取内容。
//  返回值:读出字符串的首地址
//  在此函数中测文件的大小，并malloc空间，再把文件内容读出返回，读出字符数组的首地址
/**************************************************************************/
char *read_src_file(unsigned long int *file_length, char *src_file_name)
{
    FILE *fp = fopen(src_file_name, "r");
    if (NULL == fp)
    {
        perror("fopen");
        return NULL;
    }

    fseek(fp, 0, 2);
    *file_length = ftell(fp);
    rewind(fp);

    char *p = (char *)malloc(*file_length + 1);
    if (NULL == p)
    {
        perror("malloc");
        return NULL;
    }

    fread(p, *file_length, 1, fp);

    fclose(fp);

    return p;
}

/**************************************************************************/
// 函数功能:加密字符串
// 参数：
//	src_file_text:要加密的字符串。 length:字符串的长度
//  	password: 加密密码
//  返回值: 加密后的字符串的首地址
//  加密原理字符数组中每个元素加上password
/**************************************************************************/
char *file_text_encrypt(char *src_file_text, unsigned long int length, unsigned int password)
{
    int i = 0;
    for (i = 0; i < length; i++)
    {
        src_file_text[i] += password;
    }

    return src_file_text;
}
// 函数功能:将字符串保存到目的文件中
// 参数：
//	text:要保存的字符串首地址
//	file_name :目的文件的名字
//	length:字符串的长度
// 思想：传入字符数组的首地址和数组的大小及保存后的文件的名字，即可保存数组到文件中
/**************************************************************************/
void save_file(char *text, unsigned long int length, char *file_name)
{
    FILE *fp = fopen(file_name, "w");
    if (NULL == fp)
    {
        perror("fopen");
        return;
    }

    fwrite(text, length, 1, fp);

    fclose(fp);
    if (text != NULL)
    {
        free(text);
        text = NULL;
    }
    printf("save sucess\n");
    return;
}

/**************************************************************************/
// 函数功能:解密字符串
// 参数：
//	src_file_text:要解密的字符串。 length:字符串的长度
//  	password: 解密密码
//  返回值: 解密后的字符串的首地址
// 思想;把数组中的每个元素减去password 给自己赋值。
/**************************************************************************/
char *file_text_decrypt(char *src_file_text, unsigned long int length, unsigned int password)
{
    int i = 0;
    for (i = 0; i < length; i++)
    {
        src_file_text[i] -= password;
    }

    return src_file_text;
}