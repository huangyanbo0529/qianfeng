#include <stdio.h>

void test01()
{

    FILE *fp = fopen("a.txt", "w");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    char *text = "hello BK2302";
    while (*text)
    {
        fputc(*text, fp);
        text++;
    }

    fclose(fp);
}
void test02()
{

    FILE *fp = fopen("a.txt", "r");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    char buf[128] = "";
    int i = 0;
    while (1)
    {
        char ch = fgetc(fp);
        if (ch == EOF) // EOF代表文件末尾 只有文本文件才有EOF
            break;
        buf[i] = ch;
        i++;
    }

    printf("%s\n", buf);

    fclose(fp);
}

void test03()
{
    FILE *fp = fopen("a.txt", "w");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    char *text = "hello\0BK2302 good";
    int len = fputs(text, fp);
    printf("len=%d\n", len);

    fclose(fp);
}
void test04()
{
    FILE *fp = fopen("a.txt", "r");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    while (1)
    {
        char buf[128] = "";
        char *ret = fgets(buf, sizeof(buf), fp);
        if (ret == NULL)
            break;
        printf("%s\n", buf);
    }

    fclose(fp);
}
struct hero
{
    char name[16];
    int atk;
    int def;
};
void test05()
{
    struct hero arr[5] = {{"德玛", 50, 80}, {"小法", 70, 50}, {"小炮", 90, 60}, {"盲僧", 80, 80}, {"提莫", 90, 80}};

    FILE *fp = fopen("hero.txt", "w");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    // 将结构体数组的内容写入文件
    size_t ret = fwrite(arr, sizeof(struct hero), 5, fp);
    printf("ret=%d\n", ret);

    fclose(fp);
}

void test06()
{
    struct hero arr[5];

    FILE *fp = fopen("hero.txt", "w");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    // 将结构体数组的内容写入文件
    size_t ret = fread(arr, sizeof(struct hero), 10, fp);
    printf("ret=%d\n", ret);

    int i = 0;
    for (i = 0; i < 5; i++)
    {
        printf("%s %d %d\n", arr[i].name, arr[i].atk, arr[i].def);
    }

    fclose(fp);
}
void test07()
{
    FILE *fp = fopen("a.txt", "r");

    char buf[128] = "";
    int ret = fread(buf, 10, 10, fp);
    printf("%d\n", ret);
    printf("buf=%s\n", buf);
    fclose(fp);
}

void test08()
{
    struct hero arr[5] = {{"德玛", 50, 80}, {"小法", 70, 50}, {"小炮", 90, 60}, {"盲僧", 80, 80}, {"提莫", 90, 80}};

    FILE *fp = fopen("hero.txt", "w");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    int i = 0;
    for (i = 0; i < 5; i++)
    {
        fprintf(fp, "英雄:%s 攻击:%d 防御:%d\n", arr[i].name, arr[i].atk, arr[i].def);
    }

    fclose(fp);
}
void test09()
{
    struct hero arr[5];

    FILE *fp = fopen("hero.txt", "r");
    if (fp == NULL)
    {
        perror("fopen");
        return;
    }

    // 将结构体数组的内容写入文件
    int i = 0;
    for (i = 0; i < 5; i++)
    {
        fscanf(fp, "英雄:%s 攻击:%d 防御:%d\n", arr[i].name, &arr[i].atk, &arr[i].def);
    }

    for (i = 0; i < 5; i++)
    {
        printf("%s %d %d\n", arr[i].name, arr[i].atk, arr[i].def);
    }

    fclose(fp);
}

void test10()
{
    FILE *fp = fopen("a.txt", "w+");

    char buf1[128] = "hello world1";
    fputs(buf1, fp);

    int len = ftell(fp);
    printf("len=%d\n", len);

    fclose(fp);
}
void test11()
{
    FILE *fp = fopen("a.txt", "r");
    if (NULL == fp)
    {
        perror("fopen");
        return;
    }

    // 得到文件总大小
    // 将文件指针定位文件的尾部
    fseek(fp, 0, 2);
    // 获取文件长度
    int len = ftell(fp);
    // 复位文件流指针
    rewind(fp);

    // 根据文件总大小申请堆区空间
    char *msg = (char *)malloc(len + 1);

    // 读取数据
    fread(msg, len, 1, fp);
    printf("len=%d\n", len);
    printf("msg=%s\n", msg);

    fclose(fp);
}
int main(int argc, char const *argv[])
{
    test11();
    return 0;
}
