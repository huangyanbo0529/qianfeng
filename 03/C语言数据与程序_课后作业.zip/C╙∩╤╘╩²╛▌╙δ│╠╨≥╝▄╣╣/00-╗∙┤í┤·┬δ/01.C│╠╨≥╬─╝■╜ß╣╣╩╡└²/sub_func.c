float my_sum(float a,float b)
{
	return a + b;
}

float my_dec(float a,float b)
{
	return a - b;
}

float my_mux(float a,float b)
{
	return a * b;
}

float my_dvi(float a,float b)
{
	return a / b;
}