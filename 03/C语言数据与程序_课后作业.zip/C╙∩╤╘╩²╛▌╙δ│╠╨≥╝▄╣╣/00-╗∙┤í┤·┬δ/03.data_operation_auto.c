#include <stdio.h>
int main()
{
	int num=5;
	printf("s1=%d\n",num/2);
	printf("s2=%lf\n",num/2.0);
	return 0;
}
