#include<stdio.h>
void test01()
{
	//sizeof是测量类型的大小
	//不以f结尾的小数为double
	printf("%ld\n",sizeof(3.14));//8B
	//以f结尾的小数为float
	printf("%ld\n",sizeof(3.14f));//4B
	
	//%f输出的是float类型
	printf("%f\n", 3.14f);
	//%lf输出的是double类型
	printf("%lf\n", 3.14);
}

void test02()
{
	float f=0.0f;
	
	printf("请输入一个float数值:");
	scanf("%f", &f);
	
	printf("f=%f\n", f);
}

void test03()
{
	//%d输出字符的ASCII值
	printf("%d\n",'a');
	
	//%c输出字符
	printf("%c\n",'a');
	printf("%c\n", 97);
	//在内存中'a'和97是等价的
	
	printf("%ld\n",sizeof(char));//1B
	//'a'取的的ASCII值97 sizeof是对97测量 所以4字节
	printf("%ld\n",sizeof('a'));//4B
}


void test04()
{
	char ch='\0';//'\0'的ASCII值数值0
	
	printf("请输入一个字符:");
	//%c提取一个字符
	//scanf("%c", &ch);
	//ch = getchar();
	getchar();
	ch = getchar();
	
	printf("ch=%c\n",ch);
	printf("ch=%d\n",ch);
}

void test05()
{
	char ch='a';
	ch = ch-32;
	printf("ch=%c\n",ch);
}
void test06()
{
	printf("############################\n");
	//%3d默认右对齐
	printf("#%3d#\n", 12);
	printf("#%3d#\n", 1234);
	
	//%-3d 左对齐
	printf("#%-3d#\n", 12);
	
	//%03d 占3位宽 不足 补0
	printf("#%03d#\n", 12);
	
	//%-03d 无效
	//printf("#%-03d#\n", 12);
	
	//%5.2f 5表示整个数的总位宽为5  2表示小数部分的位宽为2
	printf("#%5.2f#",3.1445926f);
}

void test07()
{
	//不管多少进制 在内存中都是二进制存储
	//不同的进制 只是数值的表现形式
	int data = 100;
	printf("十进制data=%d\n",data);
	printf("八进制data=%#o\n",data);
	printf("十六进制data=%#x\n",data);
	
}


int main(int argc,char *argv[])
{
	test07();
	return 0;
}
