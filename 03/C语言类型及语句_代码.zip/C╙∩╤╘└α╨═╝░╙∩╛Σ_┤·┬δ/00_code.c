//include头文件包含 stdio 标准输入输出头文件
#include<stdio.h>
int num=100;
//系统自动调用main函数（他是程序的入口）
//每一个c语言项目 有且仅有一个main
int main(int argc,char *argv[])
{//复合语句（下方就是函数体）
	//分号;作为语句的结束
	//printf将""这种的内容当成字符串输出
	//\n是换行符 行刷新
	printf("hello world\n");
	
	//1、返回函数的值  2、结束当前函数
	return 0;
}
