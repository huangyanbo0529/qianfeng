#include<stdio.h>
void test01()
{
	int arr[3][4];
	int row = sizeof(arr)/sizeof(arr[0]);
	int col = sizeof(arr[0])/sizeof(arr[0][0]);
	
	int i=0;
	for(i=0;i<row;i++)
	{
		int j=0;
		for(j=0;j<col;j++)
		{
			printf("%d ", arr[i][j]);	
		}
		printf("\n");
	}
}
int main(int argc,char *argv[])
{
	test01();
	return 0;
}
