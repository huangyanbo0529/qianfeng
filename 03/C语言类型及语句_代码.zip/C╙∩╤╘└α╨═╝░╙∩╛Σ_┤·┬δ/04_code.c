#include<stdio.h>
#if 0
void test01()
{
	unsigned short a = 100;
	printf("a=%#x\n",a);//0x64==0000 0000 0110 0100
	
	short b = 100;
	printf("b=%#x\n",b);//0x64==0000 0000 0110 0100
	
	b = -100;
	//原码 1000 0000 0110 0100
	//反码 1111 1111 1001 1011
	//补码 1111 1111 1001 1100
	printf("b=%#x\n",b);//0xffffff9c
	
	b=0123;//原码 0000 0000 0101 0011
	printf("b=%#x\n",b);//0x00000053 == 0x53
	
	b=0x8001;//原码 1000 0000 0000 0001
	printf("b=%#x\n",b);//0xffff8001
}
void test02()
{
	unsigned int data=0;
	data=10;//内存:0000 0000 0000 0000 0000 0000 0000 1010
	//对于无符号变量 %u提取 内存原样输出
	printf("%u\n",data);//10
	//%d 提取 先看内存的最高位 如果为0 原样输出
	printf("有符号提取%d\n",data);//10
	
	//将-10赋值给无符号数 先将-10转成无符号数（-10的补码）
	data=-10;//-10的补码1111 1111 1111 1111 1111 1111 1111 0110
	printf("%u\n",data);//‭4294967286=1111 1111 1111 1111 1111 1111 1111 0110‬
	//%d 提取 先看内存的最高位 如果为1 表明为某个负数的补码 需要再次求补码 得出原码
	printf("有符号提取%d\n",data);//-10
	
	data=0x80000001;//内存:1000 0000 0000 0000 0000 0000 0000 0001
	printf("%u\n",data);//原样输出2147483649=1000 0000 0000 0000 0000 0000 0000 0001
	//1111 1111 1111 1111 1111 1111 1111 1111 ==-2147483647
	printf("有符号提取%d\n",data);//-2147483647
}
void test03()
{
	int data=0;
	data=10;//内存:0000 0000 0000 0000 0000 0000 0000 1010
	//对于无符号变量 %u提取 内存原样输出
	printf("%u\n",data);//10
	//%d 提取 先看内存的最高位 如果为0 原样输出
	printf("有符号提取%d\n",data);//10
	
	//存储-10的补码
	data=-10;//-10的补码1111 1111 1111 1111 1111 1111 1111 0110
	printf("%u\n",data);//‭4294967286=1111 1111 1111 1111 1111 1111 1111 0110‬
	//%d 提取 先看内存的最高位 如果为1 表明为某个负数的补码 需要再次求补码 得出原码
	printf("有符号提取%d\n",data);//-10
	
	data=0x80000001;//内存:1000 0000 0000 0000 0000 0000 0000 0001
	printf("%u\n",data);//原样输出2147483649=1000 0000 0000 0000 0000 0000 0000 0001
	//1111 1111 1111 1111 1111 1111 1111 1111 ==-2147483647
	printf("有符号提取%d\n",data);//-2147483647
}

void test04()
{
	int a=-10;
	unsigned int b=4;
	//有符号和无符号参加运算 先将有符号转换无符号
	//先将-10转成无符号数（-10的补码）+4 是一个很大的数 所以大于0
	if(a+b>0)
	{
		printf("大于0\n");//结果为>0
	}
	else
	{
		printf("小于0\n");
	}
	
	//%x 内存原样数据
	printf("%x\n",a+b);//0xfffffffa
	
	printf("%d\n",a+b);//-6
	
}

void test05()
{
	char a=1;
	short b=2;
	
	//char short不管是否是混合运算 只要是运算 都将char short先转换成int
	printf("%ld\n",sizeof(a+a));//4
	printf("%ld\n",sizeof(b+b));//4
	printf("%ld\n",sizeof(a+b));//4
	
	//a没有运算 此处 只是测量a变量的类型大小 为1字节
	printf("%ld\n",sizeof(a));//1
}

void test06()
{
	float f=3.94f;
	int num = 0;
	
	//在该语句 f临时转换成int  一旦该语句结束 f立马恢复float
	num = (int)f;
	
	printf("f=%f,num=%d\n", f, num);//f=3.940000,num=3
}
void test07()
{
	printf("%d\n", 5%3);
}
void test08()
{
	int a=5;
	int b=6;
	(a!=5) && (b=200);
	printf("b=%d\n", b);
}

void test09()
{
	int data = -10;//内存数据:1111 1111 1111 1111 1111 1111 1111 0110
	data = data >> 16;
	printf("%#x\n",data);//逻辑右移0000 0000 0000 0000 1111 1111 1111 1111 == 0x0000ffff == 0xffff
						 //算术右移1111 1111 1111 1111 1111 1111 1111 1111 == 0xffffffff
	if(data == 0xffffffff)
	{
		printf("算术右移\n");
	}
	else if(data == 0xffff)
	{
		printf("逻辑右移\n");
	}
}

void test10()
{
	int a = 10;
	int b = 5;
	
	a>5?(a=100):(b=200);
	
	printf("a=%d,b=%d\n",a,b);
	
}

void test11()
{
	int num = 0;
	num = 1,2,3,4;
	printf("num=%d\n",num);//1
	
	int data = 0;
	data = (1,2,3,4);
	printf("data=%d\n",data);//4
}

void test12()
{
	int data = 0;
	printf("请输入一个int数值:");
	scanf("%d",&data);
	
	if(data % 3 == 0)
	{
		printf("0\n");
	}
	else if(data %3 == 1)
	{
		printf("1\n");
	}
	else if(data % 3 == 2)
	{
		printf("2\n");
	}
}
void test13()
{
	int data = 0;
	printf("请输入一个int数值:");
	scanf("%d",&data);
	int n =0;
	switch(data%3)
	{
	case 0+n:
		printf("0\n");
		//break;
	case 1:
		printf("1\n");
		break;
	case 2:
		printf("2\n");
		break;
	}
}
#endif
void test14()
{
	char ch = '\0';
	printf("请输入盲僧的技能:");
	ch = getchar();
	
	switch(ch)
	{
	case 'q':
	case 'Q':
		printf("天音波\n");
		break;
	case 'w':
	case 'W':
		printf("铁布衫\n");
		break;
	}
}

void test15()
{
	int i;
	int sum;
	for( i=1,sum=0; i<=100; i=i+1)
	{
		if(i==50)
			continue;//continue后的代码在本次无法执行
		sum = sum+i;
	}
	printf("sum=%d\n",sum);//1~100除去50的和 == 5000
}

void test16()
{
	int i=0;//第6行
	for(i=1;i<=9;i=i+1)
	{
		int j=1;
		for(j=1;j<=i;j=j+1)
		{
			printf("%2d*%-2d=%-2d ",j,i,j*i);
		}
		printf("\n");
	}
	
	
}

void test17()
{
	int i=1;
	int sum = 0;
	
	do
	{
		sum+=i;
		i=i+1;
	}while(i<=100);
	printf("sum = %d\n",sum);
	
}

void test18()
{
	printf("---------001-----------\n");
	printf("---------002-----------\n");
	goto here;
	printf("---------003-----------\n");
	printf("---------004-----------\n");
	printf("---------005-----------\n");
	here:
	printf("---------006-----------\n");
	printf("---------007-----------\n");
	
}

void test19()
{
	int i=5;
	for(i=9;i>0;i=i-1)
	{
		int j=1;
		for(j=1;j<=i;j=j+1)
		{
			printf("%d*%d=%d ",j,i,j*i);
		}
		printf("\n");
	}
	
}

void test20()
{
	int data = 0;
	for(data=0;data<1000;data=data+1)
	{
		//data可能是水仙花数
		//1、取出data每位上的额数值
		int a = data/100;
		int b = data/10%10;
		int c = data%10;
		
		//2、判断是否是水仙花数
		if(data == (a*a*a + b*b*b + c*c*c))
		{
			printf("%d是水仙花数\n",data);
		}
	}
}

void test21()
{
	int year=0;
	int month = 0;
	int day=0;
	int sum = 0;
	printf("请输入年月日:");
	scanf("%d %d %d",&year,&month,&day);
	
	//加的整月的天数
	switch(month-1)
	{
		case 11:
			sum+=30;
		case 10:
			sum+=31;
		case 9:
			sum+=30;
		case 8:
			sum+=31;
		case 7:
			sum+=31;
		case 6:
			sum+=30;
		case 5:
			sum+=31;
		case 4:
			sum+=30;
		case 3:
			sum+=31;
		case 2:
			sum+=28;
		case 1:
			sum+=31;
			break;
	}
	
	//加号数
	sum+=day;
	
	//加平闰年的那一天
	if((month>=3) && ((year%4==0)&&(year%100!=0)) || (year%400==0))
		sum+=1;
	printf("%d %d %d是这一年的第%d天\n",year,month,day,sum);
}
int main(int argc,char *argv[])
{
	test21();
	return 0;
}
